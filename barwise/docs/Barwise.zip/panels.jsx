// Alternate center panels: Verbalization, Fact Population, YAML, DDL

function VerbalizationPanel({ model, onSelect }) {
  return (
    <div style={{ padding: 32, overflow: "auto", height: "100%", maxWidth: 820, margin: "0 auto" }}>
      <div style={{ fontSize: 11, fontWeight: 600, color: "var(--text-subtle)", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 6 }}>FORML Verbalization</div>
      <h1 style={{ fontSize: 22, fontWeight: 600, margin: "0 0 20px" }}>{model.name}</h1>
      <div style={{ fontSize: 13, lineHeight: 1.7, color: "var(--text)", display: "flex", flexDirection: "column", gap: 18 }}>
        <section>
          <h3 style={verbH3}>Object Types</h3>
          {model.objectTypes.filter(o => o.kind === "entity").map(o => (
            <p key={o.id} style={verbP}>
              <button onClick={() => onSelect(o.id)} style={verbLink(o.kind)}>{o.name}</button>
              <span> is an entity type identified by </span>
              <em>{o.refMode || "—"}</em>.
            </p>
          ))}
        </section>
        <section>
          <h3 style={verbH3}>Fact Types</h3>
          {model.factTypes.map(ft => (
            <p key={ft.id} style={verbP}>
              <button onClick={() => onSelect(ft.id)} style={verbLink("fact")}>{ft.shortName}</button>
              <span style={{ color: "var(--text-muted)" }}> — </span>
              <span style={{ fontStyle: "italic" }}>{verbalize(ft, model)}</span>
            </p>
          ))}
        </section>
      </div>
    </div>
  );
}
const verbH3 = { fontSize: 13, fontWeight: 600, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: 0.5, margin: "0 0 8px", paddingBottom: 6, borderBottom: "1px solid var(--border)" };
const verbP = { margin: "6px 0" };
const verbLink = (kind) => ({
  background: "transparent", border: "none", padding: 0, fontSize: "inherit",
  color: kind === "entity" ? "var(--entity)" : kind === "value" ? "var(--value)" : "var(--accent-text)",
  fontWeight: 600, cursor: "pointer", fontFamily: "inherit", textDecoration: "underline", textUnderlineOffset: 2, textDecorationColor: "var(--border-strong)",
});

function FactPopulationPanel({ model, onSelect }) {
  const [sel, setSel] = React.useState("ft.Appt_for_Patient_with_Doctor");
  const ft = model.factTypes.find(f => f.id === sel);
  const rows = model.sampleFacts[sel] || [];
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "var(--bg)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 16px", borderBottom: "1px solid var(--border)", background: "var(--bg-panel)" }}>
        <span style={{ fontSize: 11, fontWeight: 600, color: "var(--text-subtle)", textTransform: "uppercase", letterSpacing: 0.4 }}>Fact Type</span>
        <select value={sel} onChange={e => setSel(e.target.value)}
          style={{ padding: "4px 8px", fontSize: 12.5, background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: 5, color: "var(--text)", fontFamily: "inherit", minWidth: 280 }}>
          {model.factTypes.map(f => <option key={f.id} value={f.id}>{f.shortName}</option>)}
        </select>
        <div style={{ flex: 1 }} />
        <button style={{ ...sbtn }}><Icon name="plus" size={11} /> Add row</button>
      </div>
      <div style={{ padding: "10px 16px", background: "var(--bg-panel)", borderBottom: "1px solid var(--border)", fontSize: 12, color: "var(--text-muted)", fontStyle: "italic" }}>
        {ft?.reading}
      </div>
      <div style={{ flex: 1, overflow: "auto", padding: 16 }}>
        <table style={{ borderCollapse: "separate", borderSpacing: 0, width: "100%", fontSize: 12.5, background: "var(--bg-panel)", border: "1px solid var(--border)", borderRadius: 6 }}>
          <thead>
            <tr>
              {ft.roles.map(r => {
                const p = model.objectTypes.find(o => o.id === r.player);
                return (
                  <th key={r.id} style={thStyle}>
                    <div style={{ fontSize: 11, color: "var(--text-subtle)", textTransform: "uppercase", letterSpacing: 0.4, marginBottom: 2 }}>{r.name}</div>
                    <button onClick={() => onSelect(p.id)} style={{ background: "transparent", border: "none", padding: 0, color: p.kind === "entity" ? "var(--entity)" : "var(--value)", fontWeight: 600, fontSize: 12.5, cursor: "pointer", fontFamily: "inherit" }}>{p.name}</button>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => (
              <tr key={i}>
                {row.map((cell, j) => (
                  <td key={j} style={tdStyle}><code style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11.5 }}>{cell}</code></td>
                ))}
              </tr>
            ))}
            <tr>
              {ft.roles.map((_, j) => (
                <td key={j} style={{ ...tdStyle, color: "var(--text-subtle)", fontStyle: "italic" }}>
                  <input placeholder="new…" style={{ width: "100%", border: "none", background: "transparent", fontSize: 11.5, fontFamily: "'JetBrains Mono', monospace", color: "var(--text)", outline: "none" }} />
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
const thStyle = { textAlign: "left", padding: "10px 12px", borderBottom: "1px solid var(--border)", background: "var(--bg-subtle)", position: "sticky", top: 0 };
const tdStyle = { padding: "8px 12px", borderBottom: "1px solid var(--border)", color: "var(--text)" };
const sbtn = { display: "flex", alignItems: "center", gap: 4, padding: "4px 9px", fontSize: 11.5, background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: 5, color: "var(--text)", cursor: "pointer", fontFamily: "inherit" };

function YamlPanel({ model }) {
  const yaml = React.useMemo(() => renderYaml(model), [model]);
  return (
    <div style={{ height: "100%", overflow: "auto", background: "var(--bg-panel)", padding: 0 }}>
      <div style={{ padding: "10px 16px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 8, position: "sticky", top: 0, background: "var(--bg-panel)", zIndex: 1 }}>
        <code style={{ fontSize: 11.5, color: "var(--text-muted)", fontFamily: "'JetBrains Mono', monospace" }}>clinic-appointments.orm.yaml</code>
        <div style={{ flex: 1 }} />
        <button style={sbtn}><Icon name="save" size={11} /> Save</button>
      </div>
      <pre style={{ margin: 0, padding: 16, fontSize: 11.5, fontFamily: "'JetBrains Mono', monospace", lineHeight: 1.6, color: "var(--text)", whiteSpace: "pre" }}>
        {yaml}
      </pre>
    </div>
  );
}

function renderYaml(model) {
  let out = `orm_version: "1.0"\nmodel:\n  name: ${model.name}\n  object_types:\n`;
  for (const o of model.objectTypes) {
    out += `    - name: ${o.name}\n      kind: ${o.kind}\n`;
    if (o.refMode) out += `      reference_mode: ${o.refMode}\n`;
    if (o.dataType) out += `      data_type: ${o.dataType}\n`;
    if (o.definition) out += `      definition: ${o.definition}\n`;
  }
  out += `  fact_types:\n`;
  for (const f of model.factTypes) {
    out += `    - name: ${f.shortName}\n      roles:\n`;
    for (const r of f.roles) {
      const p = model.objectTypes.find(o => o.id === r.player);
      out += `        - player: ${p.name}\n          role_name: ${r.name}${r.mandatory ? "\n          mandatory: true" : ""}\n`;
    }
    out += `      constraints:\n`;
    for (const c of f.constraints) {
      out += `        - type: ${c.type}\n          roles: [${c.roles.join(", ")}]\n`;
    }
  }
  return out;
}

function DdlPanel({ model }) {
  const ddl = `-- Generated from ${model.name}\n-- Target: PostgreSQL\n\nCREATE TABLE patient (\n  medical_record_number VARCHAR(20) PRIMARY KEY,\n  primary_doctor_provider_id VARCHAR(20) NOT NULL REFERENCES doctor(provider_id)\n);\n\nCREATE TABLE doctor (\n  provider_id VARCHAR(20) PRIMARY KEY,\n  specialty VARCHAR(30) NOT NULL CHECK (specialty IN ('cardiology','dermatology','family medicine','orthopedics','pediatrics'))\n);\n\nCREATE TABLE appointment (\n  confirmation_number VARCHAR(20) PRIMARY KEY,\n  patient_medical_record_number VARCHAR(20) NOT NULL REFERENCES patient(medical_record_number),\n  doctor_provider_id VARCHAR(20) NOT NULL REFERENCES doctor(provider_id),\n  appointment_date DATE NOT NULL,\n  time_slot TIME NOT NULL,\n  visit_reason VARCHAR(500),\n  status VARCHAR(20) NOT NULL CHECK (status IN ('scheduled','checked-in','in-progress','completed','cancelled','no-show')),\n  follow_up_note VARCHAR(500),\n  UNIQUE (patient_medical_record_number, appointment_date, time_slot),\n  UNIQUE (doctor_provider_id, appointment_date, time_slot)\n);\n\nCREATE TABLE exam_room (\n  room_number VARCHAR(10) PRIMARY KEY\n);\n\nCREATE TABLE doctor_room_assignment (\n  doctor_provider_id VARCHAR(20) NOT NULL REFERENCES doctor(provider_id),\n  room_number VARCHAR(10) NOT NULL REFERENCES exam_room(room_number),\n  assignment_date DATE NOT NULL,\n  PRIMARY KEY (doctor_provider_id, assignment_date)\n);\n`;
  return (
    <div style={{ height: "100%", overflow: "auto", background: "var(--bg-panel)" }}>
      <div style={{ padding: "10px 16px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 8, position: "sticky", top: 0, background: "var(--bg-panel)", zIndex: 1 }}>
        <code style={{ fontSize: 11.5, color: "var(--text-muted)" }}>Relational mapping → PostgreSQL</code>
        <div style={{ flex: 1 }} />
        <button style={sbtn}><Icon name="save" size={11} /> Export</button>
      </div>
      <pre style={{ margin: 0, padding: 16, fontSize: 11.5, fontFamily: "'JetBrains Mono', monospace", lineHeight: 1.6, color: "var(--text)", whiteSpace: "pre" }}>{ddl}</pre>
    </div>
  );
}

function CmdK({ open, onClose, model, onSelect }) {
  const [q, setQ] = React.useState("");
  React.useEffect(() => { if (open) setQ(""); }, [open]);
  if (!open) return null;
  const ql = q.toLowerCase();
  const results = [
    ...model.objectTypes.map(o => ({ id: o.id, label: o.name, kind: o.kind, sub: o.refMode || o.dataType || "" })),
    ...model.factTypes.map(f => ({ id: f.id, label: f.shortName, kind: "fact", sub: f.reading })),
  ].filter(r => !q || r.label.toLowerCase().includes(ql) || r.sub.toLowerCase().includes(ql)).slice(0, 12);
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(20,20,20,0.4)", zIndex: 100, display: "flex", alignItems: "flex-start", justifyContent: "center", paddingTop: 120 }}>
      <div onClick={e => e.stopPropagation()} style={{ width: 580, background: "var(--bg-panel)", borderRadius: 10, boxShadow: "var(--shadow-lg)", border: "1px solid var(--border)", overflow: "hidden" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 16px", borderBottom: "1px solid var(--border)" }}>
          <Icon name="search" size={14} />
          <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Search entities, facts, constraints…"
            style={{ flex: 1, border: "none", outline: "none", fontSize: 14, background: "transparent", color: "var(--text)", fontFamily: "inherit" }} />
          <kbd style={{ fontSize: 10.5, padding: "1px 5px", background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: 3, color: "var(--text-subtle)", fontFamily: "'JetBrains Mono', monospace" }}>esc</kbd>
        </div>
        <div style={{ maxHeight: 380, overflow: "auto", padding: 4 }}>
          {results.map(r => (
            <button key={r.id} onClick={() => { onSelect(r.id); onClose(); }} style={{ display: "flex", alignItems: "center", gap: 10, width: "100%", padding: "8px 12px", background: "transparent", border: "none", borderRadius: 6, textAlign: "left", cursor: "pointer", fontFamily: "inherit", color: "var(--text)" }}
              onMouseEnter={e => e.currentTarget.style.background = "var(--bg-subtle)"}
              onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
              <span style={{ color: r.kind === "entity" ? "var(--entity)" : r.kind === "value" ? "var(--value)" : "var(--text-muted)", fontSize: 11, fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.4, width: 50 }}>{r.kind === "fact" ? "fact" : r.kind}</span>
              <span style={{ fontSize: 13, fontWeight: 500, flex: 1 }}>{r.label}</span>
              <span style={{ fontSize: 11, color: "var(--text-subtle)", fontStyle: "italic", maxWidth: 260, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{r.sub}</span>
            </button>
          ))}
          {results.length === 0 && <div style={{ padding: 24, textAlign: "center", color: "var(--text-muted)", fontSize: 12.5 }}>No matches</div>}
        </div>
      </div>
    </div>
  );
}

function ValidationDrawer({ validations, open, onClose, onSelect }) {
  if (!open) return null;
  return (
    <div style={{ position: "absolute", right: 0, bottom: 0, left: 0, height: 240, background: "var(--bg-panel)", borderTop: "1px solid var(--border)", zIndex: 3, display: "flex", flexDirection: "column", boxShadow: "0 -6px 20px rgba(0,0,0,0.05)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", borderBottom: "1px solid var(--border)" }}>
        <strong style={{ fontSize: 12.5 }}>Validation</strong>
        <span style={{ fontSize: 11, color: "var(--text-muted)" }}>{validations.length} issue{validations.length===1?"":"s"}</span>
        <div style={{ flex: 1 }} />
        <button onClick={onClose} style={{ ...iconBtnClose }}><Icon name="close" /></button>
      </div>
      <div style={{ flex: 1, overflow: "auto" }}>
        {validations.map((v, i) => (
          <button key={i} onClick={() => v.elementId && onSelect(v.elementId)} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "10px 14px", width: "100%", background: "transparent", border: "none", borderBottom: "1px solid var(--border)", textAlign: "left", cursor: "pointer", fontFamily: "inherit" }}>
            <span style={{ color: v.severity === "error" ? "var(--err)" : v.severity === "warn" ? "var(--warn)" : "var(--text-muted)", marginTop: 2 }}>
              <Icon name={v.severity === "error" ? "err" : v.severity === "warn" ? "warn" : "info"} size={13} />
            </span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12.5, color: "var(--text)" }}>{v.message}</div>
              {v.elementId && <div style={{ fontSize: 11, color: "var(--text-subtle)", fontFamily: "'JetBrains Mono', monospace", marginTop: 2 }}>{v.elementId}</div>}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
const iconBtnClose = { width: 24, height: 24, display: "flex", alignItems: "center", justifyContent: "center", background: "transparent", border: "none", color: "var(--text-muted)", borderRadius: 4, cursor: "pointer" };

Object.assign(window, { VerbalizationPanel, FactPopulationPanel, YamlPanel, DdlPanel, CmdK, ValidationDrawer });
