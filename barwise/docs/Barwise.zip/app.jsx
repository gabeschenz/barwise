// Barwise — main application glue

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "accent": "indigo",
  "density": "comfortable",
  "zoom": 1.0,
  "layout": "three-pane",
  "showTree": true,
  "showInspector": true,
  "showMinimap": true,
  "showValidationBadges": true,
  "showVerbalizationInline": true,
  "showGrid": true,
  "showRoleNames": true,
  "showRefModes": true
}/*EDITMODE-END*/;

const ACCENT_HUES = { indigo: 255, teal: 190, green: 155, amber: 75, rose: 15, violet: 300 };

function App() {
  const model = window.SAMPLE_MODEL;
  const [selectedId, setSelectedId] = React.useState(null);
  const [filter, setFilter] = React.useState("");
  const [view, setView] = React.useState("diagram");
  const [cmdk, setCmdk] = React.useState(false);
  const [validationOpen, setValidationOpen] = React.useState(false);
  const [tweaksOpen, setTweaksOpen] = React.useState(false);
  const [tweaks, setTweaks] = React.useState(TWEAK_DEFAULTS);
  // Per-fact orientation overrides applied on top of the baked-in layout.
  const [orientOverrides, setOrientOverrides] = React.useState({});
  // Full layout override produced by auto-layout (null = use model.layout).
  const [autoLayout, setAutoLayout] = React.useState(null);
  // Incremented each time auto-layout runs — lets DiagramCanvas know it should
  // replace its local positions wholesale instead of preserving user drags.
  const [layoutEpoch, setLayoutEpoch] = React.useState(0);

  const runAutoLayout = React.useCallback(() => {
    if (!window.ORM_AUTOLAYOUT) return;
    const next = window.ORM_AUTOLAYOUT.layout(model, { width: 1400, height: 900, seed: Date.now() & 0xffff });
    setAutoLayout(next);
    setOrientOverrides({}); // auto-layout owns orientation now
    setLayoutEpoch(e => e + 1);
  }, [model]);

  const flipFactOrient = React.useCallback((ftId) => {
    setOrientOverrides(o => {
      const base = (model.layout[ftId]?.orient === "vertical") ? "vertical" : "horizontal";
      const current = o[ftId] ?? base;
      return { ...o, [ftId]: current === "vertical" ? "horizontal" : "vertical" };
    });
  }, [model]);

  // Augment model with orientation overrides (non-destructive)
  const effectiveModel = React.useMemo(() => {
    const baseLayout = autoLayout || model.layout;
    if (!autoLayout && Object.keys(orientOverrides).length === 0) return model;
    const layout = { ...baseLayout };
    for (const [id, orient] of Object.entries(orientOverrides)) {
      layout[id] = { ...(layout[id] || {}), orient };
    }
    return { ...model, layout };
  }, [model, orientOverrides, autoLayout]);

  // Apply theme + accent to DOM
  React.useEffect(() => {
    document.documentElement.setAttribute("data-theme", tweaks.theme);
    const h = ACCENT_HUES[tweaks.accent] ?? 255;
    const isDark = tweaks.theme === "dark";
    const root = document.documentElement;
    if (tweaks.theme !== "hc") {
      const L = isDark ? 0.7 : 0.58;
      const Lsoft = isDark ? 0.25 : 0.95;
      const Ltext = isDark ? 0.78 : 0.45;
      root.style.setProperty("--accent", `oklch(${L} 0.14 ${h})`);
      root.style.setProperty("--accent-soft", `oklch(${Lsoft} ${isDark ? 0.05 : 0.03} ${h})`);
      root.style.setProperty("--accent-text", `oklch(${Ltext} 0.16 ${h})`);
      root.style.setProperty("--entity", `oklch(${isDark ? 0.72 : 0.58} 0.14 ${h})`);
      root.style.setProperty("--entity-fill", `oklch(${isDark ? 0.28 : 0.96} ${isDark ? 0.06 : 0.02} ${h})`);
    }
  }, [tweaks.theme, tweaks.accent]);

  // Cmd+K and keyboard shortcuts
  React.useEffect(() => {
    const h = (e) => {
      const tag = (e.target && e.target.tagName) || "";
      const isInput = tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || e.target?.isContentEditable;
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault(); setCmdk(true);
      } else if (e.key === "Escape") {
        setCmdk(false);
      } else if ((e.key === "r" || e.key === "R") && !e.metaKey && !e.ctrlKey && !isInput) {
        if (selectedId && selectedId.startsWith("ft.")) {
          e.preventDefault();
          flipFactOrient(selectedId);
        }
      } else if ((e.key === "L" || (e.key === "l" && e.shiftKey)) && !e.metaKey && !e.ctrlKey && !isInput) {
        e.preventDefault();
        runAutoLayout();
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [selectedId, flipFactOrient, runAutoLayout]);

  // Edit mode handshake
  React.useEffect(() => {
    const h = (e) => {
      if (!e.data || typeof e.data !== "object") return;
      if (e.data.type === "__activate_edit_mode") setTweaksOpen(true);
      if (e.data.type === "__deactivate_edit_mode") setTweaksOpen(false);
    };
    window.addEventListener("message", h);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", h);
  }, []);

  const validations = React.useMemo(() => [
    { severity: "warn", message: "Exam room role has no uniqueness constraint spanning all roles — check n:m cardinality intent.", elementId: "ft.Doctor_assigned_Room_on_Date" },
    { severity: "info", message: "Fact type \"Appt_for_Patient_with_Doctor\" has 3 roles — consider splitting into binary facts for simpler DDL.", elementId: "ft.Appt_for_Patient_with_Doctor" },
    { severity: "warn", message: "Value type 'Specialty' has 5 enumerated values — consider promoting to entity type.", elementId: "ot.Specialty" },
  ], []);

  const layoutCols = React.useMemo(() => {
    if (tweaks.layout === "focus") return { left: 0, right: 0 };
    if (tweaks.layout === "split") return { left: tweaks.showTree ? 240 : 0, right: 380 };
    return { left: tweaks.showTree ? 260 : 0, right: tweaks.showInspector ? 320 : 0 };
  }, [tweaks.layout, tweaks.showTree, tweaks.showInspector]);

  const centerView = () => {
    if (tweaks.layout === "split") {
      return (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", height: "100%", background: "var(--bg)" }}>
          <div style={{ borderRight: "1px solid var(--border)", overflow: "hidden" }}>
            <DiagramCanvas model={effectiveModel} selectedId={selectedId} onSelect={setSelectedId}
              density={tweaks.density} zoom={tweaks.zoom} tweaks={tweaks} onFlipFact={flipFactOrient} layoutEpoch={layoutEpoch} />
          </div>
          <div style={{ overflow: "auto" }}>
            <VerbalizationPanel model={effectiveModel} onSelect={setSelectedId} />
          </div>
        </div>
      );
    }
    switch (view) {
      case "verbalize": return <VerbalizationPanel model={effectiveModel} onSelect={setSelectedId} />;
      case "facts": return <FactPopulationPanel model={effectiveModel} onSelect={setSelectedId} />;
      case "yaml": return <YamlPanel model={effectiveModel} />;
      case "ddl": return <DdlPanel model={effectiveModel} />;
      default: return <DiagramCanvas model={effectiveModel} selectedId={selectedId} onSelect={setSelectedId}
        density={tweaks.density} zoom={tweaks.zoom} tweaks={tweaks} onFlipFact={flipFactOrient} layoutEpoch={layoutEpoch} />;
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", background: "var(--bg)" }}>
      <TopBar
        modelName={model.name}
        activeView={tweaks.layout === "split" ? "split" : view}
        onViewChange={setView}
        onCmdK={() => setCmdk(true)}
        onToggleTweaks={() => setTweaksOpen(v => !v)}
        tweaks={tweaksOpen}
        onAutoLayout={runAutoLayout}
      />
      <div style={{ flex: 1, display: "flex", minHeight: 0, position: "relative" }}>
        {layoutCols.left > 0 && (
          <div style={{ width: layoutCols.left, borderRight: "1px solid var(--border)", background: "var(--bg-panel)", display: "flex", flexDirection: "column", flexShrink: 0 }}>
            <ModelTree model={effectiveModel} selectedId={selectedId} onSelect={setSelectedId}
              filter={filter} setFilter={setFilter} />
          </div>
        )}
        <div style={{ flex: 1, minWidth: 0, position: "relative", display: "flex", flexDirection: "column" }}>
          <div style={{ flex: 1, minHeight: 0, position: "relative", overflow: "hidden" }}>
            {centerView()}
          </div>
          <ValidationDrawer
            validations={validations}
            open={validationOpen}
            onClose={() => setValidationOpen(false)}
            onSelect={(id) => { setSelectedId(id); setValidationOpen(false); }}
          />
        </div>
        {layoutCols.right > 0 && (
          <div style={{ width: layoutCols.right, borderLeft: "1px solid var(--border)", background: "var(--bg-panel)", overflow: "auto", flexShrink: 0 }}>
            <Inspector model={effectiveModel} selectedId={selectedId} onSelect={setSelectedId} onFlipFact={flipFactOrient} />
          </div>
        )}
        <TweaksPanel tweaks={tweaks} setTweaks={setTweaks} open={tweaksOpen} />
      </div>
      <BottomStripWrapper
        validations={validations}
        model={effectiveModel}
        selectedId={selectedId}
        onSelect={setSelectedId}
        onToggleValidation={() => setValidationOpen(o => !o)}
      />
      <CmdK open={cmdk} onClose={() => setCmdk(false)} model={effectiveModel}
        onSelect={(id) => { setSelectedId(id); setView("diagram"); }} />
    </div>
  );
}

function BottomStripWrapper(props) {
  return (
    <div onClick={props.onToggleValidation} style={{ cursor: "pointer" }}>
      <BottomStrip {...props} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
