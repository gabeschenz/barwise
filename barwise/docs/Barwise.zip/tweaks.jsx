// Tweaks panel - controlled via parent Barwise edit-mode protocol

function TweaksPanel({ tweaks, setTweaks, open }) {
  if (!open) return null;
  const update = (k, v) => {
    setTweaks(t => ({ ...t, [k]: v }));
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [k]: v } }, "*");
  };
  return (
    <div style={tweaksPanelStyle}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "12px 14px", borderBottom: "1px solid var(--border)" }}>
        <Icon name="sliders" size={13} />
        <strong style={{ fontSize: 12.5 }}>Tweaks</strong>
      </div>
      <div style={{ padding: 14, display: "flex", flexDirection: "column", gap: 18, overflow: "auto" }}>
        <TweakGroup label="Theme">
          <SegControl value={tweaks.theme} onChange={v => update("theme", v)} options={[
            { v: "light", label: "Light" }, { v: "dark", label: "Dark" }, { v: "hc", label: "HC" }
          ]} />
        </TweakGroup>
        <TweakGroup label="Accent color">
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {[
              { v: "indigo", h: 255 }, { v: "teal", h: 190 }, { v: "green", h: 155 },
              { v: "amber", h: 75 }, { v: "rose", h: 15 }, { v: "violet", h: 300 },
            ].map(c => (
              <button key={c.v} onClick={() => update("accent", c.v)} title={c.v}
                style={{
                  width: 26, height: 26, borderRadius: 6,
                  background: `oklch(0.6 0.14 ${c.h})`,
                  border: tweaks.accent === c.v ? "2px solid var(--text)" : "1px solid var(--border)",
                  cursor: "pointer", padding: 0,
                }} />
            ))}
          </div>
        </TweakGroup>
        <TweakGroup label="Density">
          <SegControl value={tweaks.density} onChange={v => update("density", v)} options={[
            { v: "compact", label: "Compact" }, { v: "comfortable", label: "Comfy" }, { v: "spacious", label: "Airy" }
          ]} />
        </TweakGroup>
        <TweakGroup label="Diagram zoom">
          <input type="range" min={0.5} max={2} step={0.1} value={tweaks.zoom}
            onChange={e => update("zoom", parseFloat(e.target.value))} style={{ width: "100%" }} />
          <div style={{ fontSize: 11, color: "var(--text-subtle)", textAlign: "right", marginTop: 2 }}>{Math.round(tweaks.zoom*100)}%</div>
        </TweakGroup>
        <TweakGroup label="Layout">
          <SegControl value={tweaks.layout} onChange={v => update("layout", v)} options={[
            { v: "three-pane", label: "3-pane" }, { v: "focus", label: "Focus" }, { v: "split", label: "Split" }
          ]} />
          <div style={{ fontSize: 11, color: "var(--text-subtle)", marginTop: 6, lineHeight: 1.5 }}>
            <strong>3-pane</strong>: tree + canvas + inspector.<br/>
            <strong>Focus</strong>: canvas only.<br/>
            <strong>Split</strong>: diagram + verbalization side by side.
          </div>
        </TweakGroup>
        <TweakGroup label="Panels">
          {[
            { k: "showTree", label: "Model tree" },
            { k: "showInspector", label: "Inspector" },
            { k: "showMinimap", label: "Minimap" },
            { k: "showValidationBadges", label: "Validation badges on diagram" },
            { k: "showVerbalizationInline", label: "Inline verbalization on fact types" },
          ].map(p => (
            <CheckRow key={p.k} label={p.label} checked={tweaks[p.k]} onChange={v => update(p.k, v)} />
          ))}
        </TweakGroup>
        <TweakGroup label="Diagram">
          <CheckRow label="Show grid" checked={tweaks.showGrid} onChange={v => update("showGrid", v)} />
          <CheckRow label="Show role names" checked={tweaks.showRoleNames} onChange={v => update("showRoleNames", v)} />
          <CheckRow label="Show reference modes" checked={tweaks.showRefModes} onChange={v => update("showRefModes", v)} />
        </TweakGroup>
      </div>
    </div>
  );
}

function TweakGroup({ label, children }) {
  return (
    <div>
      <div style={{ fontSize: 10.5, fontWeight: 600, color: "var(--text-subtle)", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 }}>{label}</div>
      {children}
    </div>
  );
}

function SegControl({ value, onChange, options }) {
  return (
    <div style={{ display: "flex", background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: 6, padding: 2 }}>
      {options.map(o => (
        <button key={o.v} onClick={() => onChange(o.v)} style={{
          flex: 1, padding: "4px 8px", border: "none", fontSize: 11.5, fontWeight: 500,
          background: value === o.v ? "var(--bg-panel)" : "transparent",
          color: value === o.v ? "var(--text)" : "var(--text-muted)",
          borderRadius: 4, cursor: "pointer",
          boxShadow: value === o.v ? "var(--shadow-sm)" : "none",
          fontFamily: "inherit",
        }}>{o.label}</button>
      ))}
    </div>
  );
}

function CheckRow({ label, checked, onChange }) {
  return (
    <label style={{ display: "flex", alignItems: "center", gap: 8, padding: "4px 0", fontSize: 12.5, cursor: "pointer" }}>
      <span style={{
        width: 14, height: 14, borderRadius: 3, border: "1px solid var(--border-strong)",
        background: checked ? "var(--accent)" : "var(--bg-panel)",
        display: "flex", alignItems: "center", justifyContent: "center",
      }}>
        {checked && <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round"><path d="M2 5l2 2 4-4"/></svg>}
      </span>
      <span>{label}</span>
      <input type="checkbox" checked={checked} onChange={e => onChange(e.target.checked)} style={{ display: "none" }} />
    </label>
  );
}

const tweaksPanelStyle = {
  position: "absolute", top: 52, right: 12, width: 280,
  background: "var(--bg-panel)", border: "1px solid var(--border)", borderRadius: 10,
  boxShadow: "var(--shadow-lg)", zIndex: 50,
  display: "flex", flexDirection: "column", maxHeight: "calc(100vh - 80px)",
};

Object.assign(window, { TweaksPanel });
