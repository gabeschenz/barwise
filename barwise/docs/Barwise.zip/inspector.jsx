// Right inspector panel — contextual details for selected element

function Inspector({ model, selectedId, onSelect, onFlipFact }) {
  if (!selectedId) return <InspectorEmpty model={model} />;
  const ot = model.objectTypes.find(o => o.id === selectedId);
  if (ot) return <ObjectTypeInspector ot={ot} model={model} onSelect={onSelect} />;
  const ft = model.factTypes.find(f => f.id === selectedId);
  if (ft) return <FactTypeInspector ft={ft} model={model} onSelect={onSelect} onFlipFact={onFlipFact} />;
  return <InspectorEmpty model={model} />;
}

function InspectorEmpty({ model }) {
  return (
    <div style={{ padding: 16, color: "var(--text-muted)", fontSize: 12.5 }}>
      <div style={{ fontSize: 11, fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.4, color: "var(--text-subtle)", marginBottom: 12 }}>Model Overview</div>
      <div style={{ color: "var(--text)", fontSize: 14, fontWeight: 600, marginBottom: 4 }}>{model.name}</div>
      <div style={{ marginBottom: 16, fontSize: 12 }}>Select an element in the tree or diagram to see details, constraints, and verbalizations.</div>
      <div style={statGridStyle}>
        <Stat label="Entities" value={model.objectTypes.filter(o => o.kind==="entity").length} />
        <Stat label="Values" value={model.objectTypes.filter(o => o.kind==="value").length} />
        <Stat label="Fact types" value={model.factTypes.length} />
        <Stat label="Constraints" value={model.factTypes.reduce((n,f) => n+f.constraints.length, 0)} />
      </div>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div style={{ padding: "8px 10px", background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: 6 }}>
      <div style={{ fontSize: 18, fontWeight: 600, color: "var(--text)" }}>{value}</div>
      <div style={{ fontSize: 11, color: "var(--text-muted)" }}>{label}</div>
    </div>
  );
}
const statGridStyle = { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 };

function Field({ label, children }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ fontSize: 10.5, fontWeight: 600, color: "var(--text-subtle)", textTransform: "uppercase", letterSpacing: 0.4, marginBottom: 5 }}>{label}</div>
      <div style={{ fontSize: 12.5, color: "var(--text)" }}>{children}</div>
    </div>
  );
}

function ObjectTypeInspector({ ot, model, onSelect }) {
  // Find fact types involving this OT
  const involvedFTs = model.factTypes.filter(f => f.roles.some(r => r.player === ot.id));
  return (
    <div style={{ padding: 14, overflow: "auto", height: "100%" }}>
      <div style={headerRowStyle}>
        <span style={{ color: ot.kind === "entity" ? "var(--entity)" : "var(--value)", display: "inline-flex" }}>
          {ot.kind === "entity"
            ? <svg width="18" height="14" viewBox="0 0 18 14"><ellipse cx="9" cy="7" rx="8" ry="5.5" fill="var(--entity-fill)" stroke="currentColor" strokeWidth="1.3" /></svg>
            : <svg width="18" height="14" viewBox="0 0 18 14"><ellipse cx="9" cy="7" rx="8" ry="5.5" fill="var(--value-fill)" stroke="currentColor" strokeWidth="1.3" strokeDasharray="2,1.5" /></svg>
          }
        </span>
        <input value={ot.name} readOnly style={nameInputStyle} />
        <span style={kindChipStyle}>{ot.kind}</span>
      </div>
      <Field label="Definition">
        <div style={{ lineHeight: 1.55, color: "var(--text-muted)" }}>{ot.definition || "—"}</div>
      </Field>
      {ot.refMode && <Field label="Reference mode"><code style={codeStyle}>.{ot.refMode}</code></Field>}
      {ot.dataType && <Field label="Data type"><code style={codeStyle}>{ot.dataType}</code></Field>}
      {ot.values && (
        <Field label={`Allowed values (${ot.values.length})`}>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
            {ot.values.map(v => <code key={v} style={{ ...codeStyle, fontSize: 11 }}>{v}</code>)}
          </div>
        </Field>
      )}
      <Field label={`Plays roles in (${involvedFTs.length})`}>
        <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
          {involvedFTs.map(f => (
            <button key={f.id} onClick={() => onSelect(f.id)} style={linkRowStyle}>
              <svg width="14" height="8" viewBox="0 0 14 8"><rect x="0.5" y="0.5" width="6" height="7" fill="var(--fact)" stroke="var(--fact-stroke)" /><rect x="7.5" y="0.5" width="6" height="7" fill="var(--fact)" stroke="var(--fact-stroke)" /></svg>
              <span>{f.shortName}</span>
            </button>
          ))}
        </div>
      </Field>
    </div>
  );
}

function FactTypeInspector({ ft, model, onSelect, onFlipFact }) {
  const verb = verbalize(ft, model);
  const orient = model.layout?.[ft.id]?.orient === "vertical" ? "vertical" : "horizontal";
  return (
    <div style={{ padding: 14, overflow: "auto", height: "100%" }}>
      <div style={headerRowStyle}>
        <svg width="18" height="10" viewBox="0 0 18 10"><rect x="0.5" y="0.5" width="7.5" height="9" fill="var(--fact)" stroke="var(--fact-stroke)" /><rect x="9" y="0.5" width="7.5" height="9" fill="var(--fact)" stroke="var(--fact-stroke)" /></svg>
        <input value={ft.shortName} readOnly style={nameInputStyle} />
        <span style={kindChipStyle}>{ft.arity === 2 ? "binary" : ft.arity === 3 ? "ternary" : `${ft.arity}-ary`}</span>
      </div>
      <Field label="Layout">
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <div style={{ display: "flex", background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: 6, padding: 2 }}>
            {[
              { v: "horizontal", label: "Horizontal", icon: <svg width="18" height="8" viewBox="0 0 18 8"><rect x="0.5" y="0.5" width="5.5" height="7" fill="none" stroke="currentColor" /><rect x="6.5" y="0.5" width="5.5" height="7" fill="none" stroke="currentColor" /><rect x="12.5" y="0.5" width="5" height="7" fill="none" stroke="currentColor" /></svg> },
              { v: "vertical", label: "Vertical", icon: <svg width="8" height="18" viewBox="0 0 8 18"><rect x="0.5" y="0.5" width="7" height="5.5" fill="none" stroke="currentColor" /><rect x="0.5" y="6.5" width="7" height="5.5" fill="none" stroke="currentColor" /><rect x="0.5" y="12.5" width="7" height="5" fill="none" stroke="currentColor" /></svg> },
            ].map(opt => (
              <button key={opt.v} onClick={() => { if (orient !== opt.v) onFlipFact?.(ft.id); }}
                title={`Switch to ${opt.label.toLowerCase()} layout`}
                style={{
                  display: "flex", alignItems: "center", gap: 6,
                  padding: "4px 9px", border: "none", borderRadius: 4,
                  background: orient === opt.v ? "var(--bg-panel)" : "transparent",
                  color: orient === opt.v ? "var(--text)" : "var(--text-muted)",
                  fontSize: 11.5, fontWeight: 500, cursor: "pointer",
                  boxShadow: orient === opt.v ? "var(--shadow-sm)" : "none",
                  fontFamily: "inherit",
                }}>
                {opt.icon}
                <span>{opt.label}</span>
              </button>
            ))}
          </div>
          <span style={{ fontSize: 10.5, color: "var(--text-subtle)", fontFamily: "'JetBrains Mono', monospace" }}>R</span>
        </div>
      </Field>
      <Field label="Reading">
        <code style={{ ...codeStyle, display: "block", padding: "8px 10px", lineHeight: 1.55 }}>{ft.reading}</code>
      </Field>
      <Field label="Verbalization">
        <div style={{ padding: "10px 12px", background: "var(--accent-soft)", borderRadius: 6, fontSize: 12.5, lineHeight: 1.55, color: "var(--accent-text)", fontStyle: "italic" }}>
          “{verb}”
        </div>
      </Field>
      <Field label={`Roles (${ft.roles.length})`}>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          {ft.roles.map((r, i) => {
            const player = model.objectTypes.find(o => o.id === r.player);
            return (
              <div key={r.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 8px", background: "var(--bg-subtle)", borderRadius: 5 }}>
                <span style={{ fontSize: 10, color: "var(--text-subtle)", fontFamily: "'JetBrains Mono', monospace", width: 12 }}>{i+1}</span>
                <span style={{ fontSize: 12, fontStyle: "italic", color: "var(--text-muted)", flex: 1 }}>"{r.name}"</span>
                <button onClick={() => onSelect(r.player)} style={{ ...linkPillStyle, color: player.kind === "entity" ? "var(--entity)" : "var(--value)" }}>
                  {player.name}
                </button>
                {r.mandatory && <span style={{ ...tagStyle, background: "var(--text)", color: "var(--bg-panel)" }}>mand</span>}
              </div>
            );
          })}
        </div>
      </Field>
      <Field label={`Constraints (${ft.constraints.length})`}>
        <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
          {ft.constraints.map((c, i) => {
            const roleLabels = c.roles.map(rid => {
              const r = ft.roles.find(rr => rr.id === rid);
              const p = model.objectTypes.find(o => o.id === r.player);
              return p.name;
            }).join(", ");
            return (
              <div key={i} style={constraintRowStyle}>
                <svg width="14" height="14" viewBox="0 0 14 14" style={{ flexShrink: 0 }}>
                  <line x1="2" y1="4" x2="12" y2="4" stroke="var(--entity)" strokeWidth="2.2" strokeLinecap="round" />
                </svg>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 11.5, fontWeight: 600 }}>Uniqueness{c.label ? ` · ${c.label}` : ""}</div>
                  <div style={{ fontSize: 11, color: "var(--text-muted)" }}>over {roleLabels}</div>
                </div>
              </div>
            );
          })}
          <button style={addConstraintStyle}><Icon name="plus" size={11} /> Add constraint</button>
        </div>
      </Field>
    </div>
  );
}

function verbalize(ft, model) {
  const names = ft.roles.map(r => model.objectTypes.find(o => o.id === r.player).name);
  if (ft.id === "ft.Appt_for_Patient_with_Doctor")
    return "Each Appointment is booked by exactly one Patient with at most one Doctor on at most one Date at at most one TimeSlot. No Patient books two Appointments on the same Date at the same TimeSlot. No Doctor is double-booked on the same Date at the same TimeSlot.";
  if (ft.id === "ft.Doctor_has_Specialty")
    return `Each ${names[0]} has exactly one ${names[1]}.`;
  if (ft.id === "ft.Appt_has_Status")
    return `Each Appointment has exactly one Status.`;
  if (ft.id === "ft.Patient_primary_Doctor")
    return "Each Patient has exactly one primary Doctor.";
  if (ft.id === "ft.Doctor_in_Room_on_Date")
    return "Each Doctor-Date pair uses at most one ExamRoom.";
  return `Each ${names[0]} ${ft.roles[0].name} some ${names[1]}.`;
}

const headerRowStyle = { display: "flex", alignItems: "center", gap: 8, marginBottom: 14 };
const nameInputStyle = { flex: 1, padding: "5px 8px", fontSize: 14, fontWeight: 600, border: "1px solid transparent", background: "transparent", color: "var(--text)", outline: "none", fontFamily: "inherit", borderRadius: 4 };
const kindChipStyle = { fontSize: 10, fontWeight: 600, padding: "2px 7px", borderRadius: 10, background: "var(--bg-subtle)", color: "var(--text-muted)", border: "1px solid var(--border)", textTransform: "uppercase", letterSpacing: 0.4 };
const codeStyle = { fontFamily: "'JetBrains Mono', monospace", fontSize: 11.5, padding: "2px 6px", background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: 4, color: "var(--text)" };
const linkRowStyle = { display: "flex", alignItems: "center", gap: 7, padding: "5px 8px", background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: 5, color: "var(--text)", fontSize: 12, cursor: "pointer", fontFamily: "inherit", textAlign: "left" };
const linkPillStyle = { padding: "2px 8px", background: "var(--bg-panel)", border: "1px solid var(--border)", borderRadius: 100, fontSize: 11.5, fontWeight: 500, cursor: "pointer", fontFamily: "inherit" };
const tagStyle = { fontSize: 9.5, fontWeight: 600, padding: "1px 5px", borderRadius: 3, textTransform: "uppercase", letterSpacing: 0.3 };
const constraintRowStyle = { display: "flex", alignItems: "flex-start", gap: 8, padding: "7px 9px", background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: 5 };
const addConstraintStyle = { display: "flex", alignItems: "center", gap: 5, padding: "6px 9px", background: "transparent", color: "var(--text-muted)", border: "1px dashed var(--border-strong)", borderRadius: 5, fontSize: 11.5, cursor: "pointer", fontFamily: "inherit" };

Object.assign(window, { Inspector, verbalize });
