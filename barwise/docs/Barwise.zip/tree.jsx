// Left panel: model tree / outliner

const { useState: useStateTree } = React;

function ModelTree({ model, selectedId, onSelect, filter, setFilter }) {
  const [collapsed, setCollapsed] = useStateTree({});
  const toggle = (k) => setCollapsed(c => ({ ...c, [k]: !c[k] }));

  const entities = model.objectTypes.filter(o => o.kind === "entity");
  const values = model.objectTypes.filter(o => o.kind === "value");
  const facts = model.factTypes;

  const matches = (txt) => !filter || txt.toLowerCase().includes(filter.toLowerCase());

  const Section = ({ id, label, count, children, icon }) => (
    <div style={{ marginBottom: 2 }}>
      <button onClick={() => toggle(id)} style={sectionHeaderStyle}>
        <span style={{ transform: collapsed[id] ? "rotate(-90deg)" : "rotate(0)", transition: "transform 0.15s", display: "inline-flex" }}>
          <Icon name="chevronDown" size={10} />
        </span>
        <Icon name={icon} size={12} />
        <span>{label}</span>
        <span style={{ color: "var(--text-subtle)", fontWeight: 400, fontSize: 11 }}>{count}</span>
      </button>
      {!collapsed[id] && <div>{children}</div>}
    </div>
  );

  const Row = ({ item, kind, depth = 0, badge, sub }) => {
    const selected = selectedId === item.id;
    return (
      <button onClick={() => onSelect(item.id)} style={{
        ...rowStyle,
        paddingLeft: 10 + depth * 14,
        background: selected ? "var(--accent-soft)" : "transparent",
        color: selected ? "var(--accent-text)" : "var(--text)",
      }}>
        <span style={{
          width: 14, height: 14, display: "inline-flex", alignItems: "center", justifyContent: "center",
          color: kind === "entity" ? "var(--entity)" : kind === "value" ? "var(--value)" : "var(--text-muted)",
        }}>
          {kind === "entity" && <svg width="12" height="10" viewBox="0 0 12 10"><ellipse cx="6" cy="5" rx="5" ry="3.5" fill="var(--entity-fill)" stroke="currentColor" strokeWidth="1.2" /></svg>}
          {kind === "value" && <svg width="12" height="10" viewBox="0 0 12 10"><ellipse cx="6" cy="5" rx="5" ry="3.5" fill="var(--value-fill)" stroke="currentColor" strokeWidth="1.2" strokeDasharray="2,1.5" /></svg>}
          {kind === "fact" && <svg width="12" height="8" viewBox="0 0 12 8"><rect x="0.5" y="0.5" width="5" height="7" fill="var(--fact)" stroke="var(--fact-stroke)" strokeWidth="1" /><rect x="6.5" y="0.5" width="5" height="7" fill="var(--fact)" stroke="var(--fact-stroke)" strokeWidth="1" /></svg>}
        </span>
        <span style={{ flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", textAlign: "left" }}>
          {item.name || item.shortName}
          {sub && <span style={{ color: "var(--text-subtle)", fontWeight: 400, marginLeft: 6, fontSize: 11 }}>{sub}</span>}
        </span>
        {badge && <span style={badgeStyle}>{badge}</span>}
      </button>
    );
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ padding: "10px 10px 8px", borderBottom: "1px solid var(--border)" }}>
        <div style={{ position: "relative" }}>
          <div style={{ position: "absolute", left: 8, top: "50%", transform: "translateY(-50%)", color: "var(--text-subtle)" }}>
            <Icon name="search" size={12} />
          </div>
          <input
            value={filter} onChange={e => setFilter(e.target.value)}
            placeholder="Filter model…"
            style={{
              width: "100%", padding: "5px 8px 5px 26px", fontSize: 12,
              background: "var(--bg-subtle)", border: "1px solid var(--border)",
              borderRadius: 5, color: "var(--text)", outline: "none",
              fontFamily: "inherit",
            }}
          />
        </div>
      </div>
      <div style={{ flex: 1, overflow: "auto", padding: "6px 0" }}>
        <Section id="ent" label="Entity Types" count={entities.length} icon="layers">
          {entities.filter(o => matches(o.name)).map(o => (
            <Row key={o.id} item={o} kind="entity" sub={o.refMode ? `.${o.refMode}` : null} />
          ))}
        </Section>
        <Section id="val" label="Value Types" count={values.length} icon="hash">
          {values.filter(o => matches(o.name)).map(o => (
            <Row key={o.id} item={o} kind="value" sub={o.dataType} />
          ))}
        </Section>
        <Section id="ft" label="Fact Types" count={facts.length} icon="link">
          {facts.filter(f => matches(f.shortName)).map(f => {
            const arityBadge = f.arity === 1 ? "unary" : f.arity === 2 ? "binary" : f.arity === 3 ? "ternary" : `${f.arity}-ary`;
            return <Row key={f.id} item={f} kind="fact" badge={arityBadge} />;
          })}
        </Section>
        <Section id="views" label="Saved Views" count={3} icon="eye">
          {["Full model","Scheduling core","Patient-centric"].map((v,i) => (
            <button key={v} style={{ ...rowStyle, paddingLeft: 24, color: "var(--text-muted)" }}>
              <Icon name="eye" size={11} />
              <span style={{ flex: 1, textAlign: "left" }}>{v}</span>
              {i === 0 && <span style={{ ...badgeStyle, background: "var(--accent-soft)", color: "var(--accent-text)", borderColor: "transparent" }}>active</span>}
            </button>
          ))}
        </Section>
      </div>
      <div style={{ padding: "8px 10px", borderTop: "1px solid var(--border)", display: "flex", gap: 6 }}>
        <button style={addBtnStyle}><Icon name="plus" size={11} /> Entity</button>
        <button style={addBtnStyle}><Icon name="plus" size={11} /> Fact</button>
      </div>
    </div>
  );
}

const sectionHeaderStyle = {
  display: "flex", alignItems: "center", gap: 6,
  width: "100%", padding: "5px 10px",
  background: "transparent", border: "none", textAlign: "left",
  fontSize: 11.5, fontWeight: 600, color: "var(--text-muted)",
  textTransform: "uppercase", letterSpacing: 0.3, cursor: "pointer",
};
const rowStyle = {
  display: "flex", alignItems: "center", gap: 7,
  width: "100%", padding: "4px 10px",
  background: "transparent", border: "none", textAlign: "left",
  fontSize: 12.5, color: "var(--text)", cursor: "pointer",
  fontFamily: "inherit",
};
const badgeStyle = {
  fontSize: 10, padding: "0px 5px", borderRadius: 3,
  background: "var(--bg-subtle)", border: "1px solid var(--border)",
  color: "var(--text-subtle)", fontWeight: 500,
};
const addBtnStyle = {
  flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 4,
  padding: "5px 8px", fontSize: 11.5, fontWeight: 500,
  background: "var(--bg-subtle)", color: "var(--text-muted)",
  border: "1px solid var(--border)", borderRadius: 5, cursor: "pointer",
};

window.ModelTree = ModelTree;
