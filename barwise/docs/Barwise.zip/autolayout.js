// Auto-layout for ORM 2 diagrams.
//
// Strategy:
//   1. Treat object types AND fact types as nodes in a bipartite graph.
//      Edges are role connections (one per role in each fact).
//   2. Run a force-directed simulation: Coulomb repulsion between all nodes,
//      Hooke spring attraction along edges.
//   3. Post-process each fact:
//      - Decide orientation (horizontal/vertical) from PCA of player positions.
//      - Reposition the fact bar at the geometric median of its players.
//      - For n-ary facts, leave role order alone (semantic); for binaries,
//        the fact naturally ends up between its two players.
//   4. Small wiggle pass to reduce obvious edge crossings.
//
// Output: a new `layout` map compatible with model.layout.

(function () {
  const OT_W = 110, OT_H = 44;
  const ROLE_W = 38, ROLE_H = 26;

  function factSize(ft, orient) {
    const n = ft.roles.length;
    if (orient === "vertical") return { w: ROLE_W, h: ROLE_H * n };
    return { w: ROLE_W * n, h: ROLE_H };
  }

  // Compute bounding radius for collision repulsion.
  // We inflate the repulsion radius significantly for facts so players keep
  // a comfortable gutter around the bar — without this, binary facts sit
  // nearly touching their players and high-arity facts get mobbed.
  function radius(kind, ft, orient) {
    if (kind === "ot") return Math.max(OT_W, OT_H) / 2 + 12;
    const { w, h } = factSize(ft, orient);
    // Inflate by arity: more roles → more edges → more gutter needed.
    const arityBonus = Math.max(0, (ft.roles.length - 2)) * 22;
    return Math.max(w, h) / 2 + 30 + arityBonus;
  }

  function layout(model, opts = {}) {
    const W = opts.width ?? 1400;
    const H = opts.height ?? 900;
    const iters = opts.iterations ?? 400;
    const seed = opts.seed ?? 1;

    // Seeded PRNG so results are deterministic across runs.
    let s = seed;
    const rand = () => { s = (s * 16807) % 2147483647; return (s & 0x7fffffff) / 2147483647; };

    // --- Step 0: Identify satellites (degree-1 object types) ---
    //
    // For every object type, count how many fact-roles reference it.
    // If the count is exactly 1, the OT is a "satellite" of that fact.
    // Satellites get stripped from the main simulation so they don't distort
    // the core layout, then re-attached at the end.
    //
    // Also collect, for each fact, the list of non-satellite players — this
    // is the "anchor" set the satellite will orbit.
    const otDegree = {};
    for (const ot of model.objectTypes) otDegree[ot.id] = 0;
    for (const ft of model.factTypes) {
      for (const r of ft.roles) {
        if (otDegree[r.player] !== undefined) otDegree[r.player]++;
      }
    }
    const satellites = new Set();
    for (const ot of model.objectTypes) {
      if (otDegree[ot.id] === 1) satellites.add(ot.id);
    }

    // Build node list — satellites are created but parked; they don't participate
    // in forces. We'll place them properly in the post-pass.
    const nodes = {};
    for (const ot of model.objectTypes) {
      nodes[ot.id] = {
        id: ot.id, kind: "ot",
        x: W / 2 + (rand() - 0.5) * W * 0.6,
        y: H / 2 + (rand() - 0.5) * H * 0.6,
        vx: 0, vy: 0, r: radius("ot"),
        satellite: satellites.has(ot.id),
      };
    }
    for (const ft of model.factTypes) {
      // initial orient heuristic: vertical if arity >= 4
      const orient = ft.roles.length >= 4 ? "vertical" : "horizontal";
      nodes[ft.id] = {
        id: ft.id, kind: "ft", ft, orient,
        x: W / 2 + (rand() - 0.5) * W * 0.3,
        y: H / 2 + (rand() - 0.5) * H * 0.3,
        vx: 0, vy: 0, r: radius("ft", ft, orient),
      };
    }

    // Edges: each role = one edge from fact node to player node.
    // Edges touching satellites are excluded from the main sim (the satellite
    // would just drag its fact off toward the margin).
    const edges = [];
    for (const ft of model.factTypes) {
      for (const r of ft.roles) {
        if (!nodes[r.player]) continue;
        if (satellites.has(r.player)) continue;
        edges.push({ a: ft.id, b: r.player });
      }
    }

    // Force-directed simulation (Fruchterman-Reingold-ish).
    // Satellite object types sit out — they're placed by a dedicated pass later.
    const area = W * H;
    const activeNodes = Object.values(nodes).filter(n => !n.satellite);
    const k = Math.sqrt(area / activeNodes.length) * 0.55; // ideal spring length
    const nodeList = activeNodes;

    let temp = Math.min(W, H) * 0.18;
    const cooling = temp / iters;

    for (let it = 0; it < iters; it++) {
      // Repulsion
      for (let i = 0; i < nodeList.length; i++) {
        const a = nodeList[i];
        a.vx = 0; a.vy = 0;
        for (let j = 0; j < nodeList.length; j++) {
          if (i === j) continue;
          const b = nodeList[j];
          let dx = a.x - b.x, dy = a.y - b.y;
          let d = Math.sqrt(dx * dx + dy * dy);
          if (d < 0.01) { dx = rand() - 0.5; dy = rand() - 0.5; d = 0.5; }
          // extra push if overlapping bounding radii
          const minD = a.r + b.r;
          const rep = (k * k) / d + (d < minD ? (minD - d) * 2 : 0);
          a.vx += (dx / d) * rep;
          a.vy += (dy / d) * rep;
        }
      }
      // Attraction (springs)
      for (const e of edges) {
        const a = nodes[e.a], b = nodes[e.b];
        const dx = a.x - b.x, dy = a.y - b.y;
        const d = Math.sqrt(dx * dx + dy * dy) || 0.01;
        const att = (d * d) / k;
        a.vx -= (dx / d) * att;
        a.vy -= (dy / d) * att;
        b.vx += (dx / d) * att;
        b.vy += (dy / d) * att;
      }
      // Weak gravity toward canvas center (keeps things in-frame)
      for (const n of nodeList) {
        n.vx += (W / 2 - n.x) * 0.005;
        n.vy += (H / 2 - n.y) * 0.005;
      }
      // Apply with temperature cap
      for (const n of nodeList) {
        const v = Math.sqrt(n.vx * n.vx + n.vy * n.vy) || 0.01;
        const cap = Math.min(v, temp);
        n.x += (n.vx / v) * cap;
        n.y += (n.vy / v) * cap;
        // Keep inside canvas with margin
        n.x = Math.max(n.r + 20, Math.min(W - n.r - 20, n.x));
        n.y = Math.max(n.r + 20, Math.min(H - n.r - 20, n.y));
      }
      temp = Math.max(1, temp - cooling);
    }

    // ---- Orientation pass ----
    // For each fact, look at its NON-SATELLITE players' positions.
    // (Satellites haven't been placed yet — using them would be circular.)
    // PCA on the player displacements; align fact bar with the dominant axis.
    for (const ft of model.factTypes) {
      const fn = nodes[ft.id];
      const pts = ft.roles.map(r => nodes[r.player])
        .filter(p => p && !p.satellite)
        .map(p => ({ dx: p.x - fn.x, dy: p.y - fn.y }));
      if (pts.length < 2) { fn.orient = "horizontal"; continue; }
      let sxx = 0, syy = 0, sxy = 0;
      for (const p of pts) { sxx += p.dx * p.dx; syy += p.dy * p.dy; sxy += p.dx * p.dy; }
      // Angle of principal axis
      const theta = 0.5 * Math.atan2(2 * sxy, sxx - syy);
      // If principal axis is closer to vertical (|sin| > |cos|), fact should be vertical.
      const vertical = Math.abs(Math.sin(theta)) > Math.abs(Math.cos(theta));
      fn.orient = vertical ? "vertical" : "horizontal";
      fn.r = radius("ft", ft, fn.orient);
    }

    // ---- Player-side alignment pass ----
    //
    // ORM 2 rendering convention: the uniqueness bar sits on one long side of
    // the fact bar, and role-cell edges exit from the OPPOSITE long side
    // (plus the two short ends for first/last cells). So:
    //
    //   Horizontal fact: UC bar on TOP,  edges exit from BOTTOM + left/right ends.
    //   Vertical   fact: UC bar on LEFT, edges exit from RIGHT   + top/bottom ends.
    //
    // More importantly: role CELL order is FIXED by the model (semantic
    // reading order). So for a horizontal bar, the cell at index 0 sits at
    // the left; cell 1 next to it; and so on. To avoid edge crossings, each
    // player should sit UNDER its role cell's X coordinate (with some wiggle
    // room), on the exit side of the bar.
    //
    // We pull each non-satellite player toward its ideal "under role cell"
    // position. End cells get more latitude — their players can drift left/
    // right of the bar (exiting through the short end) but should still be
    // roughly on the exit side.
    for (let pass = 0; pass < 4; pass++) {
      for (const ft of model.factTypes) {
        const fn = nodes[ft.id];
        const n = ft.roles.length;
        const { w: fw, h: fh } = factSize(ft, fn.orient);

        for (let i = 0; i < n; i++) {
          const r = ft.roles[i];
          const p = nodes[r.player];
          if (!p || p.satellite) continue;

          const isEnd = i === 0 || i === n - 1;
          if (fn.orient === "horizontal") {
            // Role-cell X along the bar (center of cell)
            const cellX = fn.x - fw / 2 + ROLE_W * (i + 0.5);
            // Player should be below (exit side is bottom)
            const targetY = fn.y + fh / 2 + OT_H / 2 + 40;
            let targetX = cellX;
            if (i === 0) targetX = fn.x - fw / 2 - OT_W / 2 - 20; // left end
            if (i === n - 1) targetX = fn.x + fw / 2 + OT_W / 2 + 20; // right end
            const pullX = isEnd ? 0.25 : 0.35;
            const pullY = 0.25;
            p.x = p.x * (1 - pullX) + targetX * pullX;
            p.y = p.y * (1 - pullY) + targetY * pullY;
          } else {
            // Vertical bar: exit side is right, cells stack top-to-bottom
            const cellY = fn.y - fh / 2 + ROLE_H * (i + 0.5);
            const targetX = fn.x + fw / 2 + OT_W / 2 + 40;
            let targetY = cellY;
            if (i === 0) targetY = fn.y - fh / 2 - OT_H / 2 - 20;
            if (i === n - 1) targetY = fn.y + fh / 2 + OT_H / 2 + 20;
            const pullY = isEnd ? 0.25 : 0.35;
            const pullX = 0.25;
            p.x = p.x * (1 - pullX) + targetX * pullX;
            p.y = p.y * (1 - pullY) + targetY * pullY;
          }
        }
      }
    }

    // After pulling players into alignment, re-center each fact on the midpoint
    // of its end-cell players (players of the first and last roles). This
    // ensures the fact bar spans the natural axis between them.
    for (const ft of model.factTypes) {
      const fn = nodes[ft.id];
      const n = ft.roles.length;
      const ps = ft.roles.map(r => nodes[r.player]).filter(p => p && !p.satellite);
      if (ps.length < 2) continue;
      if (fn.orient === "horizontal") {
        // X = centroid X; Y = common-exit Y (slightly above players)
        fn.x = ps.reduce((s, p) => s + p.x, 0) / ps.length;
        const avgY = ps.reduce((s, p) => s + p.y, 0) / ps.length;
        // Want fact bar to sit ABOVE the players so they exit downward.
        fn.y = Math.min(fn.y, avgY - OT_H / 2 - 30);
      } else {
        fn.y = ps.reduce((s, p) => s + p.y, 0) / ps.length;
        const avgX = ps.reduce((s, p) => s + p.x, 0) / ps.length;
        fn.x = Math.min(fn.x, avgX - OT_W / 2 - 30);
      }
    }

    // ---- Fact centroid refinement ----
    // The player-side alignment pass above already centers each fact on its
    // players. Extra pulls here would undo that carefully-placed alignment
    // by yanking the fact toward the centroid of ALL its players, including
    // the ones that haven't yet been pulled into their role-cell columns.
    // So: skip this step when alignment is in effect.

    // ---- Satellite placement pass ----
    //
    // Each satellite belongs to exactly one fact. A satellite's fact is almost
    // always a binary of the shape (hub, satellite) — e.g. Appointment has
    // VisitReason. So the fact sits right next to its hub anchor after the
    // centroid refinement, and naive "push away from fact center" lands the
    // satellite on top of either the hub or a neighboring fact.
    //
    // Strategy:
    //   1. Compute the satellite's placement direction as AWAY FROM THE HUB
    //      (not away from the fact). That way the line hub → fact → satellite
    //      stays colinear-ish and short.
    //   2. Stand the satellite off far enough that its ellipse clears the
    //      fact bar AND doesn't land on top of any OTHER already-placed node.
    //      If a candidate angle collides, sweep around until we find clear air.
    //   3. Satellites sharing the same hub fact fan out over an arc, also
    //      checking each placement against all other nodes.
    {
      // Group satellites by their host fact.
      const byFact = {};
      for (const sid of satellites) {
        const host = model.factTypes.find(ft => ft.roles.some(r => r.player === sid));
        if (!host) continue;
        (byFact[host.id] ||= []).push(sid);
      }

      // Existing placed nodes we must avoid colliding with.
      const placed = Object.values(nodes).filter(n => !n.satellite);

      // Collision test: does placing a satellite at (x,y) overlap anything?
      // We treat object types as an ellipse bounding box and facts as their
      // oriented rectangle, both padded by `pad`.
      const pad = 28;
      function collides(x, y, ignoreIds) {
        for (const p of placed) {
          if (ignoreIds.includes(p.id)) continue;
          let pw, ph;
          if (p.kind === "ot") { pw = OT_W; ph = OT_H; }
          else {
            const sz = factSize(p.ft, p.orient);
            pw = sz.w; ph = sz.h;
          }
          // AABB overlap test between satellite OT box and neighbor box.
          const dx = Math.abs(x - p.x), dy = Math.abs(y - p.y);
          if (dx < (OT_W + pw) / 2 + pad && dy < (OT_H + ph) / 2 + pad) return true;
        }
        return false;
      }

      // Compute the model's center of mass (non-satellite nodes only).
      // Satellites should be placed OUTWARD from this center — never nested
      // between the hub and the rest of the model.
      let cmx = 0, cmy = 0, cmN = 0;
      for (const p of placed) { cmx += p.x; cmy += p.y; cmN++; }
      if (cmN > 0) { cmx /= cmN; cmy /= cmN; }
      else { cmx = W / 2; cmy = H / 2; }

      for (const [factId, sats] of Object.entries(byFact)) {
        const fn = nodes[factId];
        const ft = model.factTypes.find(f => f.id === factId);

        // Hub = the non-satellite player nearest to the fact.
        const anchors = ft.roles.map(r => nodes[r.player]).filter(p => p && !p.satellite);
        let hub = null;
        if (anchors.length > 0) {
          let bestD = Infinity;
          for (const a of anchors) {
            const d = (a.x - fn.x) ** 2 + (a.y - fn.y) ** 2;
            if (d < bestD) { bestD = d; hub = a; }
          }
        }

        // Outward direction: from the model's center of mass, past the hub.
        // This ensures satellites fan out along the OUTSIDE of the diagram,
        // on the same side as their hub — never between the hub and the core.
        let wx, wy;
        if (hub) {
          wx = hub.x - cmx;
          wy = hub.y - cmy;
          let wlen = Math.hypot(wx, wy);
          if (wlen < 20) {
            // Hub sits at the model's center. Fall back to "past the hub
            // from the fact", which at least points away from the fact.
            wx = hub.x - fn.x; wy = hub.y - fn.y;
            wlen = Math.hypot(wx, wy) || 1;
          }
          wx /= wlen; wy /= wlen;
        } else {
          // Fact has no anchor — orphan. Default to up-right.
          wx = 0.6; wy = -0.8;
        }

        const baseAngle = Math.atan2(wy, wx);
        const baseDist = 150;

        // Anchor point: the satellite stands off from the HUB (not the fact),
        // so it ends up farther from the model core than its hub.
        const anchorX = hub ? hub.x : fn.x;
        const anchorY = hub ? hub.y : fn.y;

        sats.forEach((sid, i) => {
          const sn = nodes[sid];
          const n = sats.length;
          const tArc = n === 1 ? 0 : (i / (n - 1)) - 0.5; // -0.5 .. 0.5
          const arc = n === 1 ? 0 : Math.PI / 2.5;         // up to ~72° fan
          const startAngle = baseAngle + tArc * arc;

          // Try the preferred angle, then widen the search until we find
          // a collision-free spot (or fall back to the first choice).
          const sweepOrder = [0, 20, -20, 40, -40, 60, -60, 90, -90, 120, -120, 150, -150, 180];
          let placedX = null, placedY = null;
          for (const dist of [baseDist, baseDist + 40, baseDist + 80]) {
            for (const deg of sweepOrder) {
              const a = startAngle + (deg * Math.PI) / 180;
              const tx = anchorX + Math.cos(a) * dist;
              const ty = anchorY + Math.sin(a) * dist;
              if (tx < sn.r + 20 || tx > W - sn.r - 20) continue;
              if (ty < sn.r + 20 || ty > H - sn.r - 20) continue;
              if (!collides(tx, ty, [sid, factId])) {
                placedX = tx; placedY = ty;
                break;
              }
            }
            if (placedX !== null) break;
          }
          if (placedX === null) {
            // Fallback — just put it at the preferred angle even if crowded.
            placedX = anchorX + Math.cos(startAngle) * baseDist;
            placedY = anchorY + Math.sin(startAngle) * baseDist;
          }
          sn.x = Math.max(sn.r + 20, Math.min(W - sn.r - 20, placedX));
          sn.y = Math.max(sn.r + 20, Math.min(H - sn.r - 20, placedY));

          // Move the satellite's FACT to sit between the hub and satellite.
          // That way the fact bar ends up "on the way" to the satellite,
          // not trapped between the hub and the model core.
          if (hub) {
            fn.x = (hub.x + sn.x) / 2;
            fn.y = (hub.y + sn.y) / 2;
          }

          placed.push(sn);
        });
      }
    }
    const nodeListWithSats = Object.values(nodes);

    // ---- Wiggle pass to reduce crossings ----
    // Sample several jitter offsets per node; keep the one with fewer crossings.
    function countCrossings() {
      // Treat each role as a segment fact-center → player-center
      const segs = [];
      for (const ft of model.factTypes) {
        const fn = nodes[ft.id];
        for (const r of ft.roles) {
          const p = nodes[r.player]; if (!p) continue;
          segs.push([fn.x, fn.y, p.x, p.y]);
        }
      }
      let n = 0;
      for (let i = 0; i < segs.length; i++) {
        for (let j = i + 1; j < segs.length; j++) {
          if (segSegIntersect(segs[i], segs[j])) n++;
        }
      }
      return n;
    }
    function segSegIntersect(a, b) {
      const [x1,y1,x2,y2] = a, [x3,y3,x4,y4] = b;
      // skip if they share an endpoint
      if ((x1===x3&&y1===y3)||(x1===x4&&y1===y4)||(x2===x3&&y2===y3)||(x2===x4&&y2===y4)) return false;
      const d = (x2-x1)*(y4-y3) - (y2-y1)*(x4-x3);
      if (Math.abs(d) < 1e-9) return false;
      const t = ((x3-x1)*(y4-y3) - (y3-y1)*(x4-x3)) / d;
      const u = ((x3-x1)*(y2-y1) - (y3-y1)*(x2-x1)) / d;
      return t > 0 && t < 1 && u > 0 && u < 1;
    }
    let curCx = countCrossings();
    // Build a collision test for the wiggle pass.
    function wiggleCollides(target, nx, ny) {
      for (const p of nodeListWithSats) {
        if (p.id === target.id) continue;
        let pw, ph;
        if (p.kind === "ot") { pw = OT_W; ph = OT_H; }
        else {
          const sz = factSize(p.ft, p.orient);
          pw = sz.w; ph = sz.h;
        }
        let tw, th;
        if (target.kind === "ot") { tw = OT_W; th = OT_H; }
        else {
          const sz = factSize(target.ft, target.orient);
          tw = sz.w; th = sz.h;
        }
        const dx = Math.abs(nx - p.x), dy = Math.abs(ny - p.y);
        if (dx < (tw + pw) / 2 + 10 && dy < (th + ph) / 2 + 10) return true;
      }
      return false;
    }
    const offsets = [[30,0],[-30,0],[0,30],[0,-30],[25,25],[-25,-25],[25,-25],[-25,25]];
    for (let pass = 0; pass < 4; pass++) {
      for (const n of nodeListWithSats) {
        for (const [dx, dy] of offsets) {
          const ox = n.x, oy = n.y;
          let nx = n.x + dx, ny = n.y + dy;
          nx = Math.max(n.r + 20, Math.min(W - n.r - 20, nx));
          ny = Math.max(n.r + 20, Math.min(H - n.r - 20, ny));
          if (wiggleCollides(n, nx, ny)) continue; // never move INTO an overlap
          n.x = nx; n.y = ny;
          const c = countCrossings();
          if (c < curCx) { curCx = c; }
          else { n.x = ox; n.y = oy; }
        }
      }
    }

    // ---- Final overlap-repair pass ----
    //
    // Enforce non-overlap by repeated penetration-resolve on all pairs.
    // This is a simple AABB separator: for each overlapping pair, push them
    // apart along the shortest-axis separation vector. Small steps, clamped
    // to canvas. Runs until stable or capped.
    //
    // Key detail: when a satellite OT overlaps a fact bar, we push the
    // SATELLITE more than the fact, because moving the fact drags its edges
    // and can cascade more overlap elsewhere. Similarly, facts resist being
    // pushed around by other facts.
    function nodeBox(n) {
      if (n.kind === "ot") return { w: OT_W, h: OT_H };
      return factSize(n.ft, n.orient);
    }
    function pushWeight(n) {
      // Smaller = moves more. Satellites move freely; hub OTs and facts resist.
      if (n.kind === "ot" && n.satellite) return 0.2;
      if (n.kind === "ot") return 0.8;
      return 1.0; // facts resist most
    }
    for (let pass = 0; pass < 80; pass++) {
      let maxPen = 0;
      for (let i = 0; i < nodeListWithSats.length; i++) {
        const a = nodeListWithSats[i];
        const ab = nodeBox(a);
        const aw = pushWeight(a);
        for (let j = i + 1; j < nodeListWithSats.length; j++) {
          const b = nodeListWithSats[j];
          const bb = nodeBox(b);
          const bw = pushWeight(b);
          const dx = b.x - a.x, dy = b.y - a.y;
          const minX = (ab.w + bb.w) / 2 + 18;
          const minY = (ab.h + bb.h) / 2 + 14;
          const penX = minX - Math.abs(dx);
          const penY = minY - Math.abs(dy);
          if (penX > 0 && penY > 0) {
            maxPen = Math.max(maxPen, Math.min(penX, penY));
            // Weighted push: node with smaller pushWeight moves more.
            const totalW = aw + bw;
            const aFrac = bw / totalW; // a moves more if b is heavy
            const bFrac = aw / totalW;
            if (penX < penY) {
              const push = penX + 1;
              const sign = dx >= 0 ? 1 : -1;
              // When nodes are nearly on top of each other, pick a direction
              // from a deterministic tiebreaker so we don't oscillate.
              const s = Math.abs(dx) < 0.1 ? ((a.id < b.id) ? 1 : -1) : sign;
              a.x -= s * push * aFrac;
              b.x += s * push * bFrac;
            } else {
              const push = penY + 1;
              const sign = dy >= 0 ? 1 : -1;
              const s = Math.abs(dy) < 0.1 ? ((a.id < b.id) ? 1 : -1) : sign;
              a.y -= s * push * aFrac;
              b.y += s * push * bFrac;
            }
            a.x = Math.max(40, Math.min(W - 40, a.x));
            a.y = Math.max(40, Math.min(H - 40, a.y));
            b.x = Math.max(40, Math.min(W - 40, b.x));
            b.y = Math.max(40, Math.min(H - 40, b.y));
          }
        }
      }
      if (maxPen < 0.5) break;
    }

    // Emit layout map
    const out = {};
    for (const n of nodeListWithSats) {
      if (n.kind === "ot") out[n.id] = { x: Math.round(n.x), y: Math.round(n.y) };
      else out[n.id] = { x: Math.round(n.x), y: Math.round(n.y), orient: n.orient };
    }
    return out;
  }

  window.ORM_AUTOLAYOUT = { layout };
})();
