// ORM 2 Diagram canvas — SVG, pan/zoom, drag entities

const { useState: useStateD, useRef: useRefD, useEffect: useEffectD, useCallback: useCbD, useMemo: useMemoD } = React;

const OT_W = 110, OT_H = 44;          // entity/value node size
const ROLE_W = 38, ROLE_H = 26;       // role box size
const UC_BAR_H = 2.5, UC_BAR_GAP = 5;
const MAND_R = 4;

// Intersect a ray from (cx,cy) toward (px,py) with an axis-aligned rectangle
// centered at (cx,cy) of size (w,h). Returns the point on the rect boundary.
function rectEdgePoint(cx, cy, w, h, px, py) {
  const dx = px - cx, dy = py - cy;
  if (dx === 0 && dy === 0) return { x: cx, y: cy };
  const hw = w / 2, hh = h / 2;
  const tx = dx === 0 ? Infinity : hw / Math.abs(dx);
  const ty = dy === 0 ? Infinity : hh / Math.abs(dy);
  const t = Math.min(tx, ty);
  return { x: cx + dx * t, y: cy + dy * t };
}

// Intersect ray from ellipse center toward target with ellipse boundary
function ellipseEdgePoint(cx, cy, rx, ry, px, py) {
  const dx = px - cx, dy = py - cy;
  if (dx === 0 && dy === 0) return { x: cx, y: cy };
  const t = 1 / Math.sqrt((dx * dx) / (rx * rx) + (dy * dy) / (ry * ry));
  return { x: cx + dx * t, y: cy + dy * t };
}

function DiagramCanvas({ model, selectedId, onSelect, density, zoom, tweaks, onFlipFact, layoutEpoch }) {
  const svgRef = useRefD(null);
  const wrapRef = useRefD(null);
  const [positions, setPositions] = useStateD(() => ({ ...model.layout }));

  // When auto-layout runs (layoutEpoch bumps), replace positions wholesale.
  useEffectD(() => {
    setPositions({ ...model.layout });
  }, [layoutEpoch]);

  // For non-wholesale upstream changes (e.g. orientation flip applied by App),
  // merge the change into local positions without clobbering drags in progress.
  useEffectD(() => {
    setPositions(prev => {
      const next = { ...prev };
      for (const [id, upstream] of Object.entries(model.layout)) {
        const cur = prev[id];
        if (!cur) { next[id] = { ...upstream }; continue; }
        // Keep the user's dragged x/y, but pick up changes to orient/other meta.
        if (cur.orient !== upstream.orient) {
          next[id] = { ...cur, ...upstream, x: cur.x, y: cur.y };
        }
      }
      return next;
    });
  }, [model.layout]);
  const [view, setView] = useStateD({ x: 0, y: 0, k: 0.85 });
  const [drag, setDrag] = useStateD(null);
  const [pan, setPan] = useStateD(null);
  const [hoverFt, setHoverFt] = useStateD(null);
  const didInitRef = useRefD(false);

  const densityScale = density === "compact" ? 0.9 : density === "airy" ? 1.15 : 1;

  // When the `zoom` Tweak changes, rescale around the viewport center so the
  // user's mental anchor (center of view) stays put.
  useEffectD(() => {
    if (typeof zoom !== "number") return;
    if (!didInitRef.current) return; // initial fit pass handles first render
    const el = wrapRef.current;
    if (!el) return;
    const w = el.clientWidth, h = el.clientHeight;
    const cx = w / 2, cy = h / 2;
    setView(v => {
      const nk = Math.max(0.2, Math.min(4, zoom));
      if (Math.abs(nk - v.k) < 0.001) return v;
      return { x: cx - (cx - v.x) * (nk / v.k), y: cy - (cy - v.y) * (nk / v.k), k: nk };
    });
  }, [zoom]);
  const showGrid = tweaks?.showGrid !== false;
  const showRoleNames = tweaks?.showRoleNames !== false;
  const showRefModes = tweaks?.showRefModes !== false;
  const showVerbInline = tweaks?.showVerbalizationInline !== false;

  useEffectD(() => {
    const el = wrapRef.current;
    if (!el) return;
    const w = el.clientWidth, h = el.clientHeight;
    const contentW = 1500, contentH = 900;
    const fit = Math.min((w - 40) / contentW, (h - 40) / contentH, 1);
    const k = (typeof zoom === "number" ? zoom : 1) * fit;
    setView({ x: (w - contentW * k) / 2, y: (h - contentH * k) / 2, k });
    didInitRef.current = true;
  }, []);

  const onWheel = useCbD((e) => {
    e.preventDefault();
    const rect = wrapRef.current.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    setView(v => {
      const nk = Math.max(0.2, Math.min(4, v.k * delta));
      return { x: mx - (mx - v.x) * (nk / v.k), y: my - (my - v.y) * (nk / v.k), k: nk };
    });
  }, []);

  const screenToWorld = (sx, sy) => {
    const rect = wrapRef.current.getBoundingClientRect();
    return { x: (sx - rect.left - view.x) / view.k, y: (sy - rect.top - view.y) / view.k };
  };

  const onMouseDownNode = (e, id) => {
    e.stopPropagation();
    const w = screenToWorld(e.clientX, e.clientY);
    const p = positions[id];
    setDrag({ id, startX: w.x, startY: w.y, origX: p.x, origY: p.y });
    onSelect(id);
  };

  const onMouseDown = (e) => {
    if (e.button !== 0) return;
    setPan({ startX: e.clientX, startY: e.clientY, origX: view.x, origY: view.y });
    if (e.target === svgRef.current || (e.target.tagName === "rect" && e.target.dataset.bg)) {
      onSelect(null);
    }
  };

  useEffectD(() => {
    const mv = (e) => {
      if (drag) {
        const w = screenToWorld(e.clientX, e.clientY);
        setPositions(p => ({ ...p, [drag.id]: { ...p[drag.id], x: drag.origX + (w.x - drag.startX), y: drag.origY + (w.y - drag.startY) } }));
      } else if (pan) {
        setView(v => ({ ...v, x: pan.origX + (e.clientX - pan.startX), y: pan.origY + (e.clientY - pan.startY) }));
      }
    };
    const up = () => { setDrag(null); setPan(null); };
    window.addEventListener("mousemove", mv);
    window.addEventListener("mouseup", up);
    return () => { window.removeEventListener("mousemove", mv); window.removeEventListener("mouseup", up); };
  }, [drag, pan, view.k]);

  const getOT = (id) => model.objectTypes.find(o => o.id === id);
  const getFT = (id) => model.factTypes.find(f => f.id === id);

  const ftGeom = useMemoD(() => {
    const g = {};
    for (const ft of model.factTypes) {
      const p = positions[ft.id] || { x: 700, y: 400, orient: "horizontal" };
      const n = ft.roles.length;
      const horiz = p.orient !== "vertical";
      const totalW = horiz ? ROLE_W * n : ROLE_W;
      const totalH = horiz ? ROLE_H : ROLE_H * n;
      const x0 = p.x - totalW / 2, y0 = p.y - totalH / 2;
      const roles = ft.roles.map((r, i) => ({
        role: r,
        idx: i,
        x: horiz ? x0 + i * ROLE_W : x0,
        y: horiz ? y0 : y0 + i * ROLE_H,
        cx: horiz ? x0 + i * ROLE_W + ROLE_W / 2 : x0 + ROLE_W / 2,
        cy: horiz ? y0 + ROLE_H / 2 : y0 + i * ROLE_H + ROLE_H / 2,
      }));
      g[ft.id] = { p, horiz, x0, y0, w: totalW, h: totalH, roles };
    }
    return g;
  }, [model, positions]);

  const renderObjectType = (ot) => {
    const p = positions[ot.id];
    if (!p) return null;
    const isEntity = ot.kind === "entity";
    const sel = selectedId === ot.id;
    return (
      <g key={ot.id} transform={`translate(${p.x - OT_W/2},${p.y - OT_H/2})`}
         onMouseDown={(e) => onMouseDownNode(e, ot.id)} style={{ cursor: "move" }}>
        <ellipse cx={OT_W/2} cy={OT_H/2} rx={OT_W/2} ry={OT_H/2}
                 fill={isEntity ? "var(--entity-fill)" : "var(--value-fill)"}
                 stroke={isEntity ? "var(--entity)" : "var(--value)"}
                 strokeWidth={sel ? 2.5 : 1.4}
                 strokeDasharray={isEntity ? "none" : "3,2"} />
        {sel && <ellipse cx={OT_W/2} cy={OT_H/2} rx={OT_W/2 + 4} ry={OT_H/2 + 4}
                 fill="none" stroke="var(--accent)" strokeWidth={1.5} strokeDasharray="4,3" opacity={0.6} />}
        <text x={OT_W/2} y={OT_H/2 - ((ot.refMode || ot.dataType) && showRefModes ? 3 : -4)} textAnchor="middle"
              fontSize={12.5} fontWeight={600} fill="var(--text)">{ot.name}</text>
        {ot.refMode && showRefModes && (
          <text x={OT_W/2} y={OT_H/2 + 11} textAnchor="middle"
                fontSize={10} fill="var(--text-muted)" fontStyle="italic">.{ot.refMode}</text>
        )}
        {ot.dataType && !ot.refMode && showRefModes && (
          <text x={OT_W/2} y={OT_H/2 + 11} textAnchor="middle"
                fontSize={9.5} fill="var(--text-subtle)" fontFamily="'JetBrains Mono', monospace">{ot.dataType}</text>
        )}
      </g>
    );
  };

  const renderFactType = (ft) => {
    const g = ftGeom[ft.id];
    if (!g) return null;
    const sel = selectedId === ft.id;
    const hover = hoverFt === ft.id;

    // Uniqueness constraints: bars go on the OPPOSITE side of the player-edges.
    // For horizontal fact bars → bar goes ABOVE (top of roles). The role cell
    // connects to its player OUT of the long side toward the player, but never
    // through the short ends — so the bar sitting above/below is safe.
    // For vertical fact bars → bar goes on the LEFT side of the roles.
    const spanningUnique = ft.constraints.filter(c => c.type === "uniqueness" && c.roles.length > 1);
    const simpleUnique = new Set();
    ft.constraints.filter(c => c.type === "uniqueness" && c.roles.length === 1).forEach(c => simpleUnique.add(c.roles[0]));

    // --- uniqueness bars ---
    const ucBars = [];
    if (g.horiz) {
      // Simple UC: short bar over just that role, above
      g.roles.forEach((rg) => {
        if (simpleUnique.has(rg.role.id)) {
          ucBars.push({
            x1: rg.x + 4, y1: g.y0 - UC_BAR_GAP,
            x2: rg.x + ROLE_W - 4, y2: g.y0 - UC_BAR_GAP,
            label: null,
          });
        }
      });
      // Spanning UCs: bar spans covered roles, stacked above the simple bars
      spanningUnique.forEach((c, idx) => {
        const roleIdxs = c.roles.map(rid => ft.roles.findIndex(r => r.id === rid)).sort((a,b)=>a-b);
        const startX = g.x0 + roleIdxs[0] * ROLE_W + 4;
        const endX = g.x0 + (roleIdxs[roleIdxs.length-1] + 1) * ROLE_W - 4;
        const y = g.y0 - UC_BAR_GAP - (simpleUnique.size > 0 ? 6 : 0) - idx * 6;
        ucBars.push({ x1: startX, y1: y, x2: endX, y2: y, label: c.label });
      });
    } else {
      // vertical fact: bar on left
      g.roles.forEach((rg) => {
        if (simpleUnique.has(rg.role.id)) {
          ucBars.push({
            x1: g.x0 - UC_BAR_GAP, y1: rg.y + 4,
            x2: g.x0 - UC_BAR_GAP, y2: rg.y + ROLE_H - 4,
            label: null,
          });
        }
      });
      spanningUnique.forEach((c, idx) => {
        const roleIdxs = c.roles.map(rid => ft.roles.findIndex(r => r.id === rid)).sort((a,b)=>a-b);
        const startY = g.y0 + roleIdxs[0] * ROLE_H + 4;
        const endY = g.y0 + (roleIdxs[roleIdxs.length-1] + 1) * ROLE_H - 4;
        const x = g.x0 - UC_BAR_GAP - (simpleUnique.size > 0 ? 6 : 0) - idx * 6;
        ucBars.push({ x1: x, y1: startY, x2: x, y2: endY, label: c.label });
      });
    }

    // --- edges from role-boxes to player ellipses ---
    // Per ORM 2 convention:
    //   * The first (leftmost/top) role cell connects via its OUTER short end.
    //   * The last role cell connects via its opposite outer short end.
    //   * Internal cells (in 3+-ary facts) connect via the long side AWAY FROM
    //     the uniqueness bar — i.e. bottom for horizontal facts, right for
    //     vertical facts — never through the short sides that abut neighbors.
    const n = g.roles.length;
    const edges = g.roles.map((rg) => {
      const p = positions[rg.role.player];
      if (!p) return null;
      const isFirst = rg.idx === 0;
      const isLast = rg.idx === n - 1;
      const isEnd = isFirst || isLast;

      let startX, startY;
      if (g.horiz) {
        if (isEnd) {
          // End cell: exit through outer short side, centered
          startX = isFirst ? rg.x : rg.x + ROLE_W;
          startY = rg.cy;
        } else {
          // Internal cell: exit through bottom (uniqueness bar is on top), centered
          startX = rg.cx;
          startY = rg.y + ROLE_H;
        }
      } else {
        // Vertical fact: bar on left
        if (isEnd) {
          // End cell: exit through outer short side, centered
          startX = rg.cx;
          startY = isFirst ? rg.y : rg.y + ROLE_H;
        } else {
          // Internal cell: exit through right side (bar is on left), centered
          startX = rg.x + ROLE_W;
          startY = rg.cy;
        }
      }

      // end point on ellipse
      const end = ellipseEdgePoint(p.x, p.y, OT_W / 2, OT_H / 2, startX, startY);

      return { rg, startX, startY, endX: end.x, endY: end.y, mandatory: rg.role.mandatory };
    }).filter(Boolean);

    // --- inline verbalization (under the fact bar) ---
    // The reading template already contains the player names as words, so
    // substituting {n} with the player name produces "Doctor Doctor…".
    // Drop the placeholders entirely for the inline reading.
    const verbReading = ft.reading || "";
    const verbText = verbReading.replace(/\s*\{\d+\}/g, "").replace(/\s+/g, " ").trim();
    const showVerb = showVerbInline && (ft.roles.length >= 3 || hover || sel);
    const verbY = g.y0 + g.h + 14;
    const verbX = g.x0 + g.w / 2;

    return (
      <g key={ft.id}
         onMouseDown={(e) => onMouseDownNode(e, ft.id)}
         onMouseEnter={() => setHoverFt(ft.id)}
         onMouseLeave={() => setHoverFt(null)}
         style={{ cursor: "move" }}>
        {/* Edges (behind role boxes) */}
        {edges.map((e) => (
          <g key={`e-${e.rg.role.id}`} style={{ pointerEvents: "none" }}>
            <line x1={e.startX} y1={e.startY} x2={e.endX} y2={e.endY}
                  stroke="var(--text-muted)" strokeWidth={1.3} />
            {/* Mandatory dot sits at the FACT end of the edge */}
            {e.mandatory && (
              <circle cx={e.startX} cy={e.startY} r={MAND_R}
                      fill="var(--bg)" stroke="var(--text)" strokeWidth={1.3} />
            )}
          </g>
        ))}

        {/* Selection halo */}
        {sel && (
          <rect x={g.x0 - 5} y={g.y0 - 10} width={g.w + 10} height={g.h + 20}
                fill="none" stroke="var(--accent)" strokeWidth={1.5} strokeDasharray="4,3"
                rx={5} opacity={0.6} />
        )}

        {/* Role cells */}
        {g.roles.map((rg) => {
          const r = rg.role;
          return (
            <g key={r.id}>
              <rect x={rg.x} y={rg.y} width={ROLE_W} height={ROLE_H}
                    fill="var(--fact)" stroke="var(--fact-stroke)" strokeWidth={1.2} />
              {showRoleNames && (
                <text x={rg.cx} y={rg.cy + 3.5} textAnchor="middle"
                      fontSize={8.5} fill="var(--text-muted)" style={{ pointerEvents: "none" }}>
                  {r.name}
                </text>
              )}
            </g>
          );
        })}

        {/* Uniqueness bars */}
        {ucBars.map((b, i) => (
          <g key={`uc${i}`} style={{ pointerEvents: "none" }}>
            <line x1={b.x1} y1={b.y1} x2={b.x2} y2={b.y2}
                  stroke="var(--entity)" strokeWidth={UC_BAR_H} strokeLinecap="round" />
            {b.label && (
              <text
                x={g.horiz ? (b.x1 + b.x2) / 2 : b.x1 - 6}
                y={g.horiz ? b.y1 - 4 : (b.y1 + b.y2) / 2 + 3}
                textAnchor={g.horiz ? "middle" : "end"}
                fontSize={9} fontWeight={600} fill="var(--entity)">
                {b.label}
              </text>
            )}
          </g>
        ))}

        {/* Inline verbalization */}
        {showVerb && (
          <g style={{ pointerEvents: "none" }}>
            <rect
              x={verbX - Math.min(verbText.length * 3.4, 280)}
              y={verbY - 9}
              width={Math.min(verbText.length * 6.8, 560)}
              height={16}
              rx={3}
              fill="var(--bg-panel)"
              stroke="var(--border)"
              strokeWidth={0.8}
              opacity={0.96}
            />
            <text x={verbX} y={verbY + 2} textAnchor="middle"
                  fontSize={10} fontStyle="italic" fill="var(--text-muted)">
              {verbText.length > 80 ? verbText.slice(0, 78) + "…" : verbText}
            </text>
          </g>
        )}
      </g>
    );
  };

  return (
    <div ref={wrapRef} onWheel={onWheel} onMouseDown={onMouseDown}
         style={{ position: "relative", width: "100%", height: "100%", overflow: "hidden",
                  background: "var(--bg)", cursor: pan ? "grabbing" : "default" }}>
      <svg ref={svgRef} width="100%" height="100%" style={{ display: "block" }}>
        <defs>
          <pattern id="grid" width={24} height={24} patternUnits="userSpaceOnUse" patternTransform={`translate(${view.x},${view.y}) scale(${view.k})`}>
            <circle cx={1} cy={1} r={0.8} fill="var(--border-strong)" opacity={0.5} />
          </pattern>
        </defs>
        {showGrid && <rect data-bg width="100%" height="100%" fill="url(#grid)" />}
        {!showGrid && <rect data-bg width="100%" height="100%" fill="var(--bg)" />}
        <g transform={`translate(${view.x},${view.y}) scale(${view.k * densityScale})`}>
          {model.factTypes.map(ft => renderFactType(ft))}
          {model.objectTypes.map(ot => renderObjectType(ot))}
        </g>
      </svg>

      <div style={legendStyle}>
        <div style={legendTitleStyle}>ORM 2</div>
        <LegendRow sym={<svg width="22" height="14"><ellipse cx="11" cy="7" rx="10" ry="5.5" fill="var(--entity-fill)" stroke="var(--entity)" strokeWidth="1.3" /></svg>} label="Entity type" />
        <LegendRow sym={<svg width="22" height="14"><ellipse cx="11" cy="7" rx="10" ry="5.5" fill="var(--value-fill)" stroke="var(--value)" strokeWidth="1.3" strokeDasharray="2,1.5" /></svg>} label="Value type" />
        <LegendRow sym={<svg width="22" height="14"><rect x="2" y="3" width="8" height="8" fill="var(--fact)" stroke="var(--fact-stroke)" strokeWidth="1" /><rect x="12" y="3" width="8" height="8" fill="var(--fact)" stroke="var(--fact-stroke)" strokeWidth="1" /></svg>} label="Fact type" />
        <LegendRow sym={<svg width="22" height="14"><line x1="3" y1="3" x2="19" y2="3" stroke="var(--entity)" strokeWidth="2.5" strokeLinecap="round" /><rect x="3" y="5" width="16" height="7" fill="none" stroke="var(--fact-stroke)" strokeWidth="1" /></svg>} label="Uniqueness (above)" />
        <LegendRow sym={<svg width="22" height="14"><rect x="3" y="3" width="8" height="8" fill="none" stroke="var(--fact-stroke)" strokeWidth="1" /><circle cx="11" cy="7" r="2.5" fill="var(--bg)" stroke="var(--text)" strokeWidth="1.2" /><line x1="13" y1="7" x2="20" y2="7" stroke="var(--text-muted)" strokeWidth="1.2" /></svg>} label="Mandatory" />
      </div>

      <div style={zoomControlsStyle}>
        <button style={zoomBtnStyle} onClick={() => setView(v => ({ ...v, k: Math.min(4, v.k * 1.2) }))}><Icon name="plus" size={11} /></button>
        <div style={{ fontSize: 10.5, textAlign: "center", padding: "2px 0", color: "var(--text-muted)", borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)" }}>{Math.round(view.k * 100)}%</div>
        <button style={zoomBtnStyle} onClick={() => setView(v => ({ ...v, k: Math.max(0.2, v.k * 0.83) }))}><svg width="11" height="11" viewBox="0 0 16 16" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><line x1="3" y1="8" x2="13" y2="8" /></svg></button>
      </div>

      <div style={hintStyle}>Scroll to zoom · Drag empty space to pan · Drag an entity to reposition · <kbd style={{ padding: "0 4px", border: "1px solid var(--border)", borderRadius: 3, fontSize: 10, fontFamily: "'JetBrains Mono', monospace", background: "var(--bg-subtle)" }}>R</kbd> to rotate selected fact</div>

      {/* Hover mini-toolbar for fact types */}
      {(() => {
        const ftId = hoverFt || (selectedId?.startsWith("ft.") ? selectedId : null);
        if (!ftId) return null;
        const g = ftGeom[ftId];
        if (!g) return null;
        const screenX = g.p.x * view.k * densityScale + view.x;
        const screenY = (g.y0 - 20) * view.k * densityScale + view.y;
        const ft = model.factTypes.find(f => f.id === ftId);
        const orient = g.horiz ? "horizontal" : "vertical";
        return (
          <div
            onMouseEnter={() => setHoverFt(ftId)}
            onMouseLeave={() => setHoverFt(null)}
            style={{
              position: "absolute",
              left: screenX, top: screenY,
              transform: "translate(-50%, -100%)",
              display: "flex", gap: 2,
              background: "var(--bg-panel)",
              border: "1px solid var(--border)",
              borderRadius: 6,
              padding: 3,
              boxShadow: "var(--shadow-md)",
              pointerEvents: "auto",
              zIndex: 2,
              whiteSpace: "nowrap",
            }}
          >
            <button
              onClick={(e) => { e.stopPropagation(); onFlipFact?.(ftId); }}
              title={`Rotate to ${orient === "horizontal" ? "vertical" : "horizontal"} (R)`}
              style={miniToolBtn}
            >
              {orient === "horizontal"
                ? <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.3"><rect x="1" y="5" width="3.5" height="4" /><rect x="5.2" y="5" width="3.5" height="4" /><rect x="9.4" y="5" width="3.5" height="4" /><path d="M7 2.5L8.5 1 7 -0.5 M7 1h3" transform="translate(0 1)" /></svg>
                : <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.3"><rect x="5" y="1" width="4" height="3.5" /><rect x="5" y="5.2" width="4" height="3.5" /><rect x="5" y="9.4" width="4" height="3.5" /></svg>
              }
              <span style={{ fontSize: 10.5, marginLeft: 4 }}>Rotate</span>
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onSelect(ftId); }}
              title="Edit fact type"
              style={miniToolBtn}
            >
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.3"><path d="M2 10l7-7 2 2-7 7H2v-2z" /></svg>
            </button>
          </div>
        );
      })()}
    </div>
  );
}

function LegendRow({ sym, label }) {
  return <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 11, color: "var(--text-muted)" }}>
    <span style={{ width: 22, display: "inline-flex" }}>{sym}</span>{label}
  </div>;
}

const legendStyle = {
  position: "absolute", left: 14, bottom: 14, padding: "10px 12px",
  background: "var(--bg-panel)", border: "1px solid var(--border)", borderRadius: 8,
  boxShadow: "var(--shadow-sm)", display: "flex", flexDirection: "column", gap: 5,
  backdropFilter: "blur(6px)",
};
const legendTitleStyle = {
  fontSize: 10, fontWeight: 600, color: "var(--text-subtle)",
  textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 2,
};
const zoomControlsStyle = {
  position: "absolute", right: 14, bottom: 14,
  display: "flex", flexDirection: "column",
  background: "var(--bg-panel)", border: "1px solid var(--border)", borderRadius: 6,
  boxShadow: "var(--shadow-sm)", overflow: "hidden",
};
const zoomBtnStyle = {
  width: 30, height: 26, display: "flex", alignItems: "center", justifyContent: "center",
  background: "transparent", border: "none", color: "var(--text-muted)", cursor: "pointer",
};
const miniToolBtn = {
  display: "inline-flex", alignItems: "center", padding: "4px 7px",
  background: "transparent", border: "none", borderRadius: 4,
  color: "var(--text-muted)", cursor: "pointer", fontFamily: "inherit", fontSize: 11.5,
};
const hintStyle = {
  position: "absolute", top: 14, left: "50%", transform: "translateX(-50%)",
  fontSize: 11, color: "var(--text-subtle)",
  background: "var(--bg-panel)", padding: "4px 10px", borderRadius: 100,
  border: "1px solid var(--border)",
};

window.DiagramCanvas = DiagramCanvas;
