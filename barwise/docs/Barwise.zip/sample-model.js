// Sample ORM model: Clinic Appointment Scheduling
// Simplified from examples/transcripts/clinic-appointments.orm.yaml.
// IDs are short slugs instead of UUIDs for readability.

window.SAMPLE_MODEL = {
  name: "Clinic Appointment Scheduling",
  objectTypes: [
    // Entities
    { id: "ot.Patient", name: "Patient", kind: "entity", refMode: "medical_record_number", definition: "A person who books appointments at the clinic." },
    { id: "ot.Doctor", name: "Doctor", kind: "entity", refMode: "provider_id", definition: "A medical provider at the clinic." },
    { id: "ot.Appointment", name: "Appointment", kind: "entity", refMode: "confirmation_number", definition: "A scheduled visit between a patient and a doctor." },
    { id: "ot.ExamRoom", name: "ExamRoom", kind: "entity", refMode: "room_number", definition: "A physical examination room in the clinic." },
    // Values
    { id: "ot.Specialty", name: "Specialty", kind: "value", dataType: "text(30)", definition: "The medical specialty of a doctor.", values: ["cardiology","dermatology","family medicine","orthopedics","pediatrics"] },
    { id: "ot.Date", name: "AppointmentDate", kind: "value", dataType: "date", definition: "Calendar date of an appointment." },
    { id: "ot.TimeSlot", name: "TimeSlot", kind: "value", dataType: "time", definition: "A half-hour time slot.", values: ["8:00","8:30","9:00","9:30","10:00","10:30","11:00","11:30","13:00","13:30","14:00","14:30","15:00","15:30","16:00","16:30"] },
    { id: "ot.Reason", name: "VisitReason", kind: "value", dataType: "text(500)", definition: "Free-text reason for the patient's visit." },
    { id: "ot.Status", name: "AppointmentStatus", kind: "value", dataType: "text(20)", definition: "Current status of an appointment.", values: ["scheduled","checked-in","in-progress","completed","cancelled","no-show"] },
    { id: "ot.Note", name: "FollowUpNote", kind: "value", dataType: "text(500)", definition: "Free-text note on a completed appointment." },
  ],
  factTypes: [
    {
      id: "ft.Appt_for_Patient_with_Doctor",
      reading: "Patient {0} books Appointment {1} with Doctor {2} on Date {3} at TimeSlot {4}",
      shortName: "Patient books Appointment with Doctor on Date at TimeSlot",
      roles: [
        { id: "r.a1", player: "ot.Patient",     name: "books",      mandatory: true },
        { id: "r.a2", player: "ot.Appointment", name: "is booked by", mandatory: true },
        { id: "r.a3", player: "ot.Doctor",      name: "with" },
        { id: "r.a4", player: "ot.Date",        name: "on" },
        { id: "r.a5", player: "ot.TimeSlot",    name: "at" },
      ],
      constraints: [
        // Each Appointment belongs to exactly one (Patient, Doctor, Date, TimeSlot) combination:
        { type: "uniqueness", roles: ["r.a2"] },
        // No Patient books two Appointments on the same Date at the same TimeSlot:
        { type: "uniqueness", roles: ["r.a1","r.a4","r.a5"], label: "UC1" },
        // No Doctor is double-booked on the same Date at the same TimeSlot:
        { type: "uniqueness", roles: ["r.a3","r.a4","r.a5"], label: "UC2" },
      ],
      arity: 5,
    },
    {
      id: "ft.Doctor_has_Specialty",
      reading: "Doctor {0} has Specialty {1}",
      shortName: "Doctor has Specialty",
      roles: [
        { id: "r.s1", player: "ot.Doctor", name: "has", mandatory: true },
        { id: "r.s2", player: "ot.Specialty", name: "of" },
      ],
      constraints: [{ type: "uniqueness", roles: ["r.s1"] }],
      arity: 2,
    },
    {
      id: "ft.Appt_has_Reason",
      reading: "Appointment {0} has VisitReason {1}",
      shortName: "Appointment has VisitReason",
      roles: [
        { id: "r.r1", player: "ot.Appointment", name: "has" },
        { id: "r.r2", player: "ot.Reason", name: "of" },
      ],
      constraints: [{ type: "uniqueness", roles: ["r.r1"] }],
      arity: 2,
    },
    {
      id: "ft.Appt_has_Status",
      reading: "Appointment {0} has Status {1}",
      shortName: "Appointment has Status",
      roles: [
        { id: "r.st1", player: "ot.Appointment", name: "has", mandatory: true },
        { id: "r.st2", player: "ot.Status", name: "of" },
      ],
      constraints: [{ type: "uniqueness", roles: ["r.st1"] }],
      arity: 2,
    },
    {
      id: "ft.Appt_has_Note",
      reading: "Appointment {0} has FollowUpNote {1}",
      shortName: "Appointment has FollowUpNote",
      roles: [
        { id: "r.n1", player: "ot.Appointment", name: "has" },
        { id: "r.n2", player: "ot.Note", name: "of" },
      ],
      constraints: [{ type: "uniqueness", roles: ["r.n1"] }],
      arity: 2,
    },
    {
      id: "ft.Patient_primary_Doctor",
      reading: "Patient {0} has primary Doctor {1}",
      shortName: "Patient has primary Doctor",
      roles: [
        { id: "r.p1", player: "ot.Patient", name: "has primary", mandatory: true },
        { id: "r.p2", player: "ot.Doctor", name: "is primary of" },
      ],
      constraints: [{ type: "uniqueness", roles: ["r.p1"] }],
      arity: 2,
    },
    {
      id: "ft.Doctor_in_Room_on_Date",
      reading: "Doctor {0} uses ExamRoom {1} on Date {2}",
      shortName: "Doctor uses ExamRoom on Date",
      roles: [
        { id: "r.rm1", player: "ot.Doctor", name: "uses" },
        { id: "r.rm2", player: "ot.ExamRoom", name: "is used by" },
        { id: "r.rm3", player: "ot.Date", name: "on" },
      ],
      constraints: [{ type: "uniqueness", roles: ["r.rm1","r.rm3"] }],
      arity: 3,
    },
  ],
  // Precomputed x,y positions for diagram nodes (in a 1400x900 canvas).
  layout: {
    "ot.Patient":     { x: 880, y: 180 },
    "ot.Doctor":      { x: 1120, y: 400 },
    "ot.Appointment": { x: 1160, y: 260 },
    "ot.ExamRoom":    { x: 700, y: 760 },
    "ot.Specialty":   { x: 1320, y: 400 },
    "ot.Date":        { x: 1160, y: 500 },
    "ot.TimeSlot":    { x: 1120, y: 600 },
    "ot.Reason":      { x: 700, y: 260 },
    "ot.Status":      { x: 540, y: 330 },
    "ot.Note":        { x: 700, y: 120 },
    // Fact type positions (center of bar)
    "ft.Appt_for_Patient_with_Doctor": { x: 1000, y: 400, orient: "vertical" },
    "ft.Doctor_has_Specialty":         { x: 1220, y: 400, orient: "horizontal" },
    "ft.Appt_has_Reason":              { x: 900, y: 260, orient: "horizontal" },
    "ft.Appt_has_Status":              { x: 830, y: 295, orient: "horizontal" },
    "ft.Appt_has_Note":                { x: 900, y: 180, orient: "horizontal" },
    "ft.Patient_primary_Doctor":       { x: 1000, y: 200, orient: "horizontal" },
    "ft.Doctor_in_Room_on_Date":       { x: 900, y: 620, orient: "horizontal" },
  },
  // Sample fact population for "Patient books Appointment with Doctor on Date at TimeSlot"
  sampleFacts: {
    "ft.Appt_for_Patient_with_Doctor": [
      ["MRN-884", "APT-1001", "PRV-7712", "2026-04-18", "9:00"],
      ["MRN-884", "APT-1002", "PRV-7712", "2026-04-25", "9:30"],
      ["MRN-221", "APT-1003", "PRV-7712", "2026-04-18", "10:30"],
      ["MRN-221", "APT-1004", "PRV-5031", "2026-05-02", "14:00"],
      ["MRN-557", "APT-1005", "PRV-5031", "2026-04-18", "11:00"],
    ],
    "ft.Doctor_has_Specialty": [
      ["PRV-7712", "pediatrics"],
      ["PRV-5031", "family medicine"],
      ["PRV-8820", "orthopedics"],
    ],
  },
  validations: [
    { severity: "warn",  elementId: "ft.Appt_has_Note",    message: "Follow-up note should be conditional on status = completed (subset constraint not expressed)." },
    { severity: "info",  elementId: "ot.Specialty",         message: "Value list may not be exhaustive — confirm with domain expert." },
    { severity: "error", elementId: "ft.Doctor_in_Room_on_Date", message: "Uniqueness over {Doctor, Date} prevents a doctor from using two rooms on the same day — intended?" },
  ],
};
