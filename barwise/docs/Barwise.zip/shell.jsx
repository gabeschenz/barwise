// Shell: top bar, 3-pane layout, bottom strip

const { useState, useEffect, useRef, useMemo, useCallback } = React;

function Icon({ name, size = 14 }) {
  const paths = {
    search: "M11 11l3 3M7 12a5 5 0 1 1 0-10 5 5 0 0 1 0 10z",
    layers: "M2 5l6-3 6 3-6 3-6-3zM2 8l6 3 6-3M2 11l6 3 6-3",
    diagram: "M3 3h4v4H3zM9 9h4v4H9zM7 5h2v4m0 0h-2",
    list: "M3 4h10M3 8h10M3 12h10",
    check: "M3 8l3 3 7-7",
    warn: "M8 2l6 11H2zM8 7v3M8 12v.01",
    err: "M8 2a6 6 0 1 0 0 12A6 6 0 0 0 8 2zM5 5l6 6M11 5l-6 6",
    info: "M8 7v5M8 5v.01M8 2a6 6 0 1 0 0 12A6 6 0 0 0 8 2z",
    chevron: "M5 4l3 4-3 4",
    chevronDown: "M4 5l4 3 4-3",
    plus: "M8 3v10M3 8h10",
    close: "M4 4l8 8M12 4l-8 8",
    sliders: "M3 4h7M12 4h1M3 8h1M6 8h7M3 12h9M11 12h2",
    save: "M3 3h7l3 3v7H3zM5 3v4h6V3M5 13v-3h6v3",
    play: "M4 3l8 5-8 5z",
    folder: "M2 4a1 1 0 0 1 1-1h3l2 2h5a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1z",
    hash: "M5 2l-1 12M11 2l-1 12M2 5h12M2 11h12",
    eye: "M1 8s3-5 7-5 7 5 7 5-3 5-7 5-7-5-7-5zM8 6a2 2 0 1 1 0 4 2 2 0 0 1 0-4z",
    sun: "M8 3v2M8 11v2M3 8h2M11 8h2M4.5 4.5l1.4 1.4M10.1 10.1l1.4 1.4M4.5 11.5l1.4-1.4M10.1 5.9l1.4-1.4M8 6a2 2 0 1 1 0 4 2 2 0 0 1 0-4z",
    cmd: "M4 4h3v3H4zM9 4h3v3H9zM4 9h3v3H4zM9 9h3v3H9z",
    link: "M6 9l4-4M5 4a2 2 0 0 0 0 4h2M11 8h-2a2 2 0 0 0 0 4H11",
    dot: "M8 7a1 1 0 1 1 0 2 1 1 0 0 1 0-2z",
  };
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d={paths[name] || ""} />
    </svg>
  );
}

function TopBar({ modelName, activeView, onViewChange, onCmdK, onToggleTweaks, tweaks, onAutoLayout }) {
  return (
    <div style={topBarStyle}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, paddingLeft: 14, minWidth: 260 }}>
        <BarwiseLogo />
        <div style={{ fontWeight: 600, fontSize: 13.5 }}>Barwise</div>
        <div style={{ color: "var(--text-subtle)", fontSize: 12 }}>/</div>
        <div style={{ color: "var(--text-muted)", fontSize: 12.5 }}>{modelName}</div>
        <div style={{ fontSize: 10, color: "var(--text-subtle)", padding: "1px 6px", border: "1px solid var(--border)", borderRadius: 4, marginLeft: 4 }}>ORM 2</div>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 2, flex: 1, justifyContent: "center" }}>
        {[
          { k: "diagram", label: "Diagram" },
          { k: "verbalize", label: "Verbalization" },
          { k: "facts", label: "Fact Population" },
          { k: "yaml", label: "YAML" },
          { k: "ddl", label: "SQL DDL" },
        ].map(t => (
          <button key={t.k} onClick={() => onViewChange(t.k)} style={{
            ...viewTabStyle,
            background: activeView === t.k ? "var(--bg-active)" : "transparent",
            color: activeView === t.k ? "var(--text)" : "var(--text-muted)",
          }}>{t.label}</button>
        ))}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 6, paddingRight: 10 }}>
        {onAutoLayout && (
          <button onClick={onAutoLayout} style={{ ...searchBtnStyle, minWidth: 0, gap: 5, padding: "5px 10px" }} title="Run auto-layout (Shift+L)">
            <Icon name="layers" size={12} />
            <span>Auto-layout</span>
            <kbd style={kbdStyle}>⇧L</kbd>
          </button>
        )}
        <button onClick={onCmdK} style={searchBtnStyle}>
          <Icon name="search" size={12} />
          <span>Search model…</span>
          <kbd style={kbdStyle}>⌘K</kbd>
        </button>
        <button onClick={onToggleTweaks} style={{ ...iconBtnStyle, background: tweaks ? "var(--accent-soft)" : "transparent", color: tweaks ? "var(--accent-text)" : "var(--text-muted)" }}><Icon name="sliders" /></button>
      </div>
    </div>
  );
}

function BarwiseLogo() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <ellipse cx="5" cy="12" rx="3.5" ry="2.8" stroke="var(--entity)" strokeWidth="1.4" fill="var(--entity-fill)" />
      <ellipse cx="19" cy="12" rx="3.5" ry="2.8" stroke="var(--entity)" strokeWidth="1.4" fill="var(--entity-fill)" />
      <rect x="9.5" y="10" width="5" height="4" stroke="var(--text)" strokeWidth="1.2" fill="var(--bg-panel)" />
      <line x1="12" y1="10" x2="12" y2="14" stroke="var(--text)" strokeWidth="1.2" />
      <line x1="10.2" y1="8.8" x2="13.8" y2="8.8" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" />
      <circle cx="14.5" cy="12" r="0.8" fill="var(--text)" />
    </svg>
  );
}

const topBarStyle = {
  display: "flex", alignItems: "center",
  height: 44, borderBottom: "1px solid var(--border)",
  background: "var(--bg-panel)", flexShrink: 0,
};
const viewTabStyle = {
  padding: "5px 12px", border: "none", background: "transparent",
  borderRadius: 5, fontSize: 12.5, fontWeight: 500, cursor: "pointer",
};
const searchBtnStyle = {
  display: "flex", alignItems: "center", gap: 8,
  padding: "5px 8px 5px 10px", background: "var(--bg-subtle)",
  border: "1px solid var(--border)", borderRadius: 6, fontSize: 12,
  color: "var(--text-muted)", minWidth: 220, cursor: "pointer",
};
const kbdStyle = {
  marginLeft: "auto", fontSize: 10.5, padding: "1px 5px",
  background: "var(--bg-panel)", border: "1px solid var(--border)",
  borderRadius: 3, color: "var(--text-subtle)", fontFamily: "'JetBrains Mono', monospace",
};
const iconBtnStyle = {
  width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center",
  background: "transparent", border: "1px solid transparent", borderRadius: 5, color: "var(--text-muted)",
};

function BottomStrip({ validations, model, selectedId, onSelect }) {
  const counts = useMemo(() => {
    const c = { error: 0, warn: 0, info: 0 };
    validations.forEach(v => c[v.severity === "error" ? "error" : v.severity === "warn" ? "warn" : "info"]++);
    return c;
  }, [validations]);
  const stats = useMemo(() => ({
    ot: model.objectTypes.length,
    ft: model.factTypes.length,
    entities: model.objectTypes.filter(o => o.kind === "entity").length,
    values: model.objectTypes.filter(o => o.kind === "value").length,
  }), [model]);
  return (
    <div style={{
      display: "flex", alignItems: "center",
      height: 26, borderTop: "1px solid var(--border)",
      background: "var(--bg-panel)", padding: "0 12px",
      fontSize: 11.5, color: "var(--text-muted)", gap: 16, flexShrink: 0,
    }}>
      <span><strong style={{ color: "var(--text)", fontWeight: 600 }}>{stats.entities}</strong> entity types</span>
      <span><strong style={{ color: "var(--text)", fontWeight: 600 }}>{stats.values}</strong> value types</span>
      <span><strong style={{ color: "var(--text)", fontWeight: 600 }}>{stats.ft}</strong> fact types</span>
      <div style={{ flex: 1 }} />
      {counts.error > 0 && <span style={{ display: "flex", alignItems: "center", gap: 4, color: "var(--err)" }}><Icon name="err" size={11} /> {counts.error}</span>}
      {counts.warn > 0 && <span style={{ display: "flex", alignItems: "center", gap: 4, color: "var(--warn)" }}><Icon name="warn" size={11} /> {counts.warn}</span>}
      {counts.info > 0 && <span style={{ display: "flex", alignItems: "center", gap: 4 }}><Icon name="info" size={11} /> {counts.info}</span>}
      <span style={{ color: "var(--text-subtle)" }}>clinic-appointments.orm.yaml</span>
      <span style={{ color: "var(--ok)", display: "flex", alignItems: "center", gap: 4 }}><Icon name="check" size={11} /> Valid</span>
    </div>
  );
}

Object.assign(window, { Icon, TopBar, BottomStrip });
